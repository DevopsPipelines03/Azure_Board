const https = require("https");

const ORG = process.env.ADO_ORG;
const PROJECT = process.env.ADO_PROJECT;
const PAT = process.env.ADO_PAT;

const STATUS = process.env.PIPELINE_STATUS;

const AUTH =
    "Basic " +
    Buffer.from(":" + PAT).toString("base64");

// =========================================
// API
// =========================================

function ado(
    method,
    path,
    body = null
) {

    return new Promise(
        (resolve, reject) => {

            const payload =
                body
                    ? JSON.stringify(body)
                    : null;

            const requestPath =
                `/${ORG}/${encodeURIComponent(PROJECT)}/_apis${path}` +
                (
                    path.includes("?")
                        ? "&api-version=7.1"
                        : "?api-version=7.1"
                );

            const req =
                https.request(
                    {
                        hostname: "dev.azure.com",
                        method,
                        path: requestPath,
                        headers: {
                            Authorization: AUTH,
                            "Content-Type":
                                method === "PATCH"
                                    ? "application/json-patch+json"
                                    : "application/json"
                        }
                    },
                    res => {

                        let data = "";

                        res.on(
                            "data",
                            chunk => {
                                data += chunk;
                            }
                        );

                        res.on(
                            "end",
                            () => {

                                try {

                                    resolve(
                                        JSON.parse(data)
                                    );

                                } catch {

                                    resolve({});

                                }

                            }
                        );

                    }
                );

            req.on(
                "error",
                reject
            );

            if (payload) {

                req.write(payload);

            }

            req.end();

        }
    );

}

// =========================================
// GET LATEST INTERVIEW REQUIREMENT
// =========================================

async function getLatestInterviewRequirement() {

    const result =
        await ado(
            "POST",
            "/wit/wiql",
            {
                query: `
SELECT [System.Id]
FROM WorkItems
WHERE [System.WorkItemType] = 'Interview Requirement'
ORDER BY [System.Id] DESC
`
            }
        );

    if (
        !result.workItems ||
        result.workItems.length === 0
    ) {

        throw new Error(
            "No Interview Requirement found."
        );

    }

    return result.workItems[0].id;

}

// =========================================
// GET MESSAGE
// =========================================

function getMessage(status) {

    switch (status) {

        case "IN_PROGRESS":
            return `⏳ Interview Task cloning is in progress.

Please wait while the automation creates the Interview Task.

Refresh this work item after a short time.`;

        case "COMPLETED":
            return `✅ Interview Task cloning completed successfully.

Please refresh this work item to view the cloned Interview Task.`;

        case "FAILED":
            return `❌ Interview Task cloning failed.

Please contact support or create the Interview Task manually.`;

        default:
            return "Pipeline status unavailable.";

    }

}

// =========================================
// UPDATE FIELD
// =========================================

async function updateStatus(
    workItemId,
    message
) {

    return await ado(
        "PATCH",
        `/wit/workitems/${workItemId}`,
        [
            {
                op: "add",
                path:
                    "/fields/Custom.Pipelinecompletionstatus",
                value: message
            }
        ]
    );

}

// =========================================
// MAIN
// =========================================

async function run() {

    const workItemId =
        await getLatestInterviewRequirement();

    const message =
        getMessage(
            STATUS
        );

    console.log(
        "Updating Pipeline Status:"
    );

    console.log(message);

    await updateStatus(
        workItemId,
        message
    );

    console.log(
        "Pipeline status updated."
    );

}

run().catch(error => {

    console.error(error);

    process.exit(1);

});