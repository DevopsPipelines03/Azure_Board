
const https = require("https");
 
const ORG = process.env.ADO_ORG;
const PROJECT = process.env.ADO_PROJECT;
const PAT = process.env.ADO_PAT;
 
const AUTH =
    "Basic " +
    Buffer.from(":" + PAT).toString("base64");
 
const ROLE_FIELD = "Custom.Role";
 
const TARGET_STATE =
    "Scoring";
 
// =========================================
// API
// =========================================
 
function ado(
    method,
    path,
    body = null
) {
 
    return new Promise(
        (resolve, reject) => {
 
            const payload =
                body
                    ? JSON.stringify(body)
                    : null;
 
            const requestPath =
                `/${ORG}/${encodeURIComponent(PROJECT)}/_apis${path}` +
                (
                    path.includes("?")
                        ? "&api-version=7.1"
                        : "?api-version=7.1"
                );
 
            const req =
                https.request(
                    {
                        hostname:
                            "dev.azure.com",
 
                        method,
 
                        path:
                            requestPath,
 
                        headers: {
 
                            Authorization:
                                AUTH,
 
                            "Content-Type":
                                method === "PATCH"
                                    ? "application/json-patch+json"
                                    : "application/json"
 
                        }
 
                    },
                    res => {
 
                        let data = "";
 
                        res.on(
                            "data",
                            chunk => {
                                data += chunk;
                            }
                        );
 
                        res.on(
                            "end",
                            () => {
 
                                try {
 
                                    resolve(
                                        JSON.parse(
                                            data
                                        )
                                    );
 
                                }
                                catch {
 
                                    resolve({});
 
                                }
 
                            }
                        );
 
                    }
                );
 
            req.on(
                "error",
                reject
            );
 
            if (payload) {
 
                req.write(
                    payload
                );
 
            }
 
            req.end();
 
        });
 
}
 
// =========================================
// WORK ITEM
// =========================================
 
async function getWorkItem(id) {
 
    return await ado(
        "GET",
        `/wit/workitems/${id}?$expand=relations`
    );
 
}
 
// =========================================
// GET CURRENT INTERVIEW EVALUATION
// =========================================
 
async function getLatestInterviewEvaluation() {
 
    const result =
        await ado(
            "POST",
            "/wit/wiql",
            {
                query: `
SELECT [System.Id]
FROM WorkItems
WHERE
[System.WorkItemType] = 'Interview Requirement'
ORDER BY [System.Id] DESC
`
            }
        );
 
    if (
        !result.workItems ||
        result.workItems.length === 0
    ) {
 
        throw new Error(
            "No Interview Requirement found."
        );
 
    }
 
    return result.workItems[0].id;
 
}
 
// =========================================
// REUSE FLAG
// =========================================
 
async function getReuseFlag(
    parentId
) {
 
    const parent =
        await getWorkItem(
            parentId
        );
 
    return (
        parent.fields[
            // "Custom.ReuseExistingInterviewData"
            "Custom.DoYouWantToCloneAnExistingInterviewTask"
        ] || "No"
    );
 
}
 
// =========================================
// DUPLICATE CHECK
// =========================================
 
async function alreadyHasChildTasks(
    parentId
) {
 
    const parent =
        await getWorkItem(
            parentId
        );
 
    const children =
        (
            parent.relations || []
        ).filter(
            relation =>
                relation.rel ===
                "System.LinkTypes.Hierarchy-Forward"
        );
 
    return (
        children.length > 0
    );
 
}
 
// =========================================
// VERIFY ALL CHILD TASKS COMPLETED
// =========================================
 
async function allChildTasksCompleted(
    parentId
) {
 
    const parent =
        await getWorkItem(
            parentId
        );
 
    const children =
        (
            parent.relations || []
        ).filter(
            relation =>
                relation.rel ===
                "System.LinkTypes.Hierarchy-Forward"
        );
 
    if (
        children.length === 0
    ) {
 
        return false;
 
    }
 
    for (
        const child of children
    ) {
 
        const taskId =
            child.url
                .split("/")
                .pop();
 
        const task =
            await getWorkItem(
                taskId
            );
 
        const state =
            task.fields[
                "System.State"
            ];
 
        if (
            state !==
            "Completed"
        ) {
 
            return false;
 
        }
 
    }
 
    return true;
 
}
// =========================================
// CHECK FOR OPEN INTERVIEWS FOR SAME ROLE
// =========================================
 
// async function hasOpenInterviewProcess(
//     currentEvaluationId
// ) {
 
//     const current =
//         await getWorkItem(
//             currentEvaluationId
//         );
 
//     const currentRole =
//         current.fields[
//             ROLE_FIELD
//         ];
 
//     const result =
//         await ado(
//             "POST",
//             "/wit/wiql",
//             {
//                 query: `
// SELECT [System.Id]
// FROM WorkItems
// WHERE
// [System.WorkItemType] = 'Interview Requirement'
// ORDER BY [System.Id] DESC
// `
//             }
//         );
 
//     const evaluations =
//         result.workItems || [];
 
//     for (const item of evaluations) {
 
//         if (
//             item.id === currentEvaluationId
//         ) {
 
//             continue;
 
//         }
 
//         const evaluation =
//             await getWorkItem(
//                 item.id
//             );
 
//         const role =
//             evaluation.fields[
//                 ROLE_FIELD
//             ];
 
//         if (
//             role !== currentRole
//         ) {
 
//             continue;
 
//         }
 
//         const parentState =
//             evaluation.fields[
//                 "System.State"
//             ];
 
//         //
//         // Parent must be completed
//         //
//         if (
//             parentState !== "Completed"
//         ) {
 
//             console.log(
//                 `Open Interview Requirement Found: ${item.id}`
//             );
 
//             return true;
 
//         }
 
//         const relations =
//             evaluation.relations || [];
 
//         for (
//             const relation
//             of relations
//         ) {
 
//             if (
//                 relation.rel !==
//                 "System.LinkTypes.Hierarchy-Forward"
//             ) {
 
//                 continue;
 
//             }
 
//             const childId =
//                 Number(
//                     relation.url
//                         .split("/")
//                         .pop()
//                 );
 
//             const child =
//                 await getWorkItem(
//                     childId
//                 );
 
//             const type =
//                 child.fields[
//                     "System.WorkItemType"
//                 ];
 
//             if (
//                 type !==
//                 "Interview"
//             ) {
 
//                 continue;
 
//             }
 
//             const childState =
//                 child.fields[
//                     "System.State"
//                 ];
 
//             //
//             // Child must be completed
//             //
//             if (
//                 childState !==
//                 "Completed"
//             ) {
 
//                 console.log(
//                     `Open Interview Task Found: ${childId}`
//                 );
 
//                 return true;
 
//             }
 
//         }
 
//     }
 
//     return false;
 
// }
// =========================================
// FIND ELIGIBLE INTERVIEW EVALUATION
// =========================================
 
async function findLatestEligibleEvaluation(
    currentEvaluationId
) {
 
    const current =
        await getWorkItem(
            currentEvaluationId
        );
 
    const currentRole =
        current.fields[
            ROLE_FIELD
        ];
 
    const result =
        await ado(
            "POST",
            "/wit/wiql",
            {
                query: `
SELECT [System.Id]
FROM WorkItems
WHERE
[System.WorkItemType] = 'Interview Requirement'
ORDER BY [System.Id] DESC
`
            }
        );
 
    const evaluations =
        result.workItems || [];
 
    for (
        const item of evaluations
    ) {
 
        if (
            item.id ===
            currentEvaluationId
        ) {
 
            continue;
 
        }
 
        const evaluation =
            await getWorkItem(
                item.id
            );
 
        const role =
            evaluation.fields[
                ROLE_FIELD
            ];
 
        const state =
            evaluation.fields[
                "System.State"
            ];
 
        if (
            role !== currentRole
        ) {
 
            continue;
 
        }
 
        if (
            state !==
            "Completed"
        ) {
 
            continue;
 
        }
 
        const completed =
            await allChildTasksCompleted(
                item.id
            );
 
        if (
            !completed
        ) {
 
            continue;
 
        }
 
        return item.id;
 
    }
 
    return null;
 
}
 
// =========================================
// GET REUSABLE TASK
// =========================================
 
// async function getReusableTasks(
//     evaluationId
// ) {

//     const parent =
//         await getWorkItem(
//             evaluationId
//         );

//     const children =
//         (
//             parent.relations || []
//         ).filter(
//             relation =>
//                 relation.rel ===
//                 "System.LinkTypes.Hierarchy-Forward"
//         );

//     if (
//         children.length === 0
//     ) {

//         return [];

//     }

//     const sourceTaskIds = [];

//     for (
//         const child of children
//     ) {

//         const taskId =
//             Number(
//                 child.url
//                     .split("/")
//                     .pop()
//             );

//         const task =
//             await getWorkItem(
//                 taskId
//             );

//         const type =
//     task.fields[
//         "System.WorkItemType"
//     ];

// const state =
//     task.fields[
//         "System.State"
//     ];

// if (
//     type === "Interview" &&
//     state === "Completed"
// ) {

//     sourceTaskIds.push(
//         taskId
//     );

//     console.log(
//         `Eligible Interview Found: ${taskId}`
//     );

// }
// else {

//     console.log(
//         `Skipping Interview ${taskId} because state is ${state}`
//     );

// }

//     }

//     sourceTaskIds.sort(
//         (a, b) => a - b
//     );

//     return sourceTaskIds;

// }
async function getReusableTasks(
    evaluationId
) {

    const parent =
        await getWorkItem(
            evaluationId
        );

    const children =
        (
            parent.relations || []
        ).filter(
            relation =>
                relation.rel ===
                "System.LinkTypes.Hierarchy-Forward"
        );

    if (
        children.length === 0
    ) {

        return [];

    }

    const sourceTaskIds = [];

    for (
        const child of children
    ) {

        const taskId =
            Number(
                child.url
                    .split("/")
                    .pop()
            );

        const task =
            await getWorkItem(
                taskId
            );

        const type =
            task.fields[
                "System.WorkItemType"
            ];

        const state =
            task.fields[
                "System.State"
            ];

        if (
            type === "Interview" &&
            state === "Completed"
        ) {

            sourceTaskIds.push(
                taskId
            );

            console.log(
                `Eligible Interview Found: ${taskId}`
            );

        }
        else {

            console.log(
                `Skipping Interview ${taskId} because state is ${state}`
            );

        }

    }

    sourceTaskIds.sort(
        (a, b) => a - b
    );

    return sourceTaskIds;

}

 
// =========================================
// CLONE TASK
// =========================================
 
async function createClone(
    sourceTaskId
) {
 
    const source =
        await getWorkItem(
            sourceTaskId
        );
 
    console.log(
        "================================"
    );
 
    console.log(
        "SOURCE TASK DETAILS"
    );
 
    console.log(
        "================================"
    );
 
    console.log(
        "Source Task ID:",
        sourceTaskId
    );
 
    console.log(
        "Source Title:",
        source.fields[
            "System.Title"
        ]
    );
 
    const patch = [];
 
    patch.push({
 
        op: "add",
 
        path:
            "/fields/System.Title",
 
        value:
            source.fields[
                "System.Title"
            ]
 
    });
 
    const EXCLUDED_FIELDS = [
 
        "Custom.ValidationStatussss",
        "Custom.Totalcount",
        "Custom.MarkComplete"
 
    ];
 
    for (
        const [field, value]
        of Object.entries(
            source.fields
        )
    ) {
 
        if (
 
            field.startsWith(
                "Custom."
            ) &&
 
            !EXCLUDED_FIELDS.includes(
                field
            ) &&
 
            value !== undefined &&
 
            value !== null
 
        ) {
 
            patch.push({
 
                op: "add",
 
                path:
                    `/fields/${field}`,
 
                value
 
            });
 
        }
 
    }
 
    const clone =
        await ado(
            "PATCH",
            "/wit/workitems/$Interview",
            patch
        );
 
    console.log(
        "CLONE RESPONSE:"
    );
 
    console.log(
        JSON.stringify(
            clone,
            null,
            2
        )
    );
 
    if (!clone.id) {
 
        throw new Error(
            "Interview Task creation failed."
        );
 
    }
 
    try {
 
        const stateUpdate =
            await ado(
                "PATCH",
                `/wit/workitems/${clone.id}`,
                [
                    {
                        op: "add",
                        path:
                            "/fields/System.State",
                        value:
                            TARGET_STATE
                    }
                ]
            );
 
        // console.log(
        //     "STATE UPDATE RESPONSE:"
        // );
 
        // console.log(
        //     JSON.stringify(
        //         stateUpdate,
        //         null,
        //         2
        //     )
        // );
 
    }
    catch (error) {
 
        console.log(
            "Unable to move task to Ready For Scoring."
        );
 
        console.log(
            error
        );
 
    }
 
    return clone.id;
 
}
 
// =========================================
// LINK CHILD
// =========================================
 
async function linkChildToParent(
    childId,
    parentId
) {
 
    const parent =
        await getWorkItem(
            parentId
        );
 
    await ado(
        "PATCH",
        `/wit/workitems/${childId}`,
        [
            {
                op: "add",
                path:
                    "/relations/-",
                value: {
 
                    rel:
                        "System.LinkTypes.Hierarchy-Reverse",
 
                    url:
                        parent.url
 
                }
            }
        ]
    );
 
}
 
// =========================================
// MAIN
// =========================================
 
async function run() {
 
    console.log(
        "================================"
    );
 
    console.log(
        "INTERVIEW TASK CLONING V2"
    );
 
    console.log(
        "================================"
    );
 
    const currentEvaluation =
        await getLatestInterviewEvaluation();
 
    const reuseFlag =
        await getReuseFlag(
            currentEvaluation
        );
 
    if (
        String(
            reuseFlag
        ).toLowerCase() !== "yes"
    ) {
 
        console.log(
            "Reuse Existing Interview Data = No"
        );
 
        console.log(
            "Please proceed with manual Interview creation."
        );
 
        return;
 
    }
 
    // const childExists =
    //     await alreadyHasChildTasks(
    //         currentEvaluation
    //     );
 
    // if (
    //     childExists
    // ) {
 
    //     console.log(
    //         "Interview Task already exists."
    //     );
 
    //     return;
 
    // }
 
    // const eligibleEvaluation =
    //     await findLatestEligibleEvaluation(
    //         currentEvaluation
    //     );
    const childExists =
    await alreadyHasChildTasks(
        currentEvaluation
    );
 
if (
    childExists
) {
 
    console.log(
        "Interview Task already exists."
    );
 
    return;
 
}
 
//
// NEW VALIDATION
//
 
// const openInterviewExists =
//     await hasOpenInterviewProcess(
//         currentEvaluation
//     );
 
// if (openInterviewExists) {
 
//     console.log(
//         "Active Interview Requirement or Interview Task already exists for this role."
//     );
 
//     console.log(
//         "Please complete all existing Interview Requirements and Interview Tasks before cloning."
//     );
 
//     return;
 
// }
 
//
// EXISTING CODE
//
 
const eligibleEvaluation =
    await findLatestEligibleEvaluation(
        currentEvaluation
    );
 
    if (
        !eligibleEvaluation
    ) {
 
        console.log(
            "No completed Interview Evaluation with completed Interview Tasks available for reuse."
        );
 
        console.log(
            "Please proceed with manual Interview creation."
        );
 
        return;
 
    }
 
    console.log(
        "Eligible Interview Requirement:",
        eligibleEvaluation
    );
 
    const sourceTaskIds =
    await getReusableTasks(
        eligibleEvaluation
    );

    if (
        sourceTaskIds.length === 0
    ) {
 
        console.log(
            "No reusable Interview Task found."
        );
 
        return;
 
    }
 
   for (
    const taskId
    of sourceTaskIds
) {

    console.log(
        "Source Interview Task:",
        taskId
    );

}
 
    for (
    const sourceTaskId
    of sourceTaskIds
) {

    const newTaskId =
        await createClone(
            sourceTaskId
        );

    await linkChildToParent(
        newTaskId,
        currentEvaluation
    );

    console.log(
        "New Cloned Task:",
        newTaskId
    );

}
 
    console.log(
        "Interview Task copied successfully."
    );
 
    console.log(
        "Please review assessment values and complete the Interview Task."
    );
 
    console.log(
        "Clone Process Completed."
    );
 
}
 
run().catch(error => {
 
    console.error(error);
 
    process.exit(1);
 
});