const https = require("https");

const ORG = process.env.ADO_ORG;
const PROJECT = process.env.ADO_PROJECT;
const PAT = process.env.ADO_PAT;

const AUTH =
    "Basic " +
    Buffer.from(":" + PAT).toString("base64");

// =========================================
// COMMON ADO FUNCTION
// =========================================

function ado(method, path, body = null) {

    return new Promise((resolve, reject) => {

        const payload =
            body
                ? JSON.stringify(body)
                : null;

        const requestPath =
            `/${ORG}/${encodeURIComponent(PROJECT)}/_apis${path}` +
            (
                path.includes("?")
                    ? "&api-version=7.1"
                    : "?api-version=7.1"
            );

        const req = https.request(
            {
                hostname: "dev.azure.com",
                method,
                path: requestPath,
                headers: {
                    Authorization: AUTH,
                    "Content-Type": "application/json"
                }
            },
            res => {

                let data = "";

                res.on("data", chunk => {
                    data += chunk;
                });

                res.on("end", () => {

                    try {
                        resolve(JSON.parse(data));
                    }
                    catch {
                        resolve({});
                    }

                });

            }
        );

        req.on("error", reject);

        if (payload) {
            req.write(payload);
        }

        req.end();

    });

}

// =========================================
// GET WORK ITEM
// =========================================

async function getWorkItem(id) {

    return await ado(
        "GET",
        `/wit/workitems/${id}?$expand=relations`
    );

}

// =========================================
// GET LATEST INTERVIEW REQUIREMENT
// =========================================

async function getLatestInterviewRequirement() {

    const result =
        await ado(
            "POST",
            "/wit/wiql",
            {
                query: `
SELECT [System.Id]
FROM WorkItems
WHERE [System.WorkItemType] = 'Interview Requirement'
ORDER BY [System.Id] DESC
`
            }
        );

    if (
        !result.workItems ||
        result.workItems.length === 0
    ) {
        throw new Error(
            "No Interview Requirement found."
        );
    }

    return result.workItems[0].id;

}

// =========================================
// FETCH JSON RESPONSES
// =========================================

async function run() {

    console.log("================================");
    console.log("FETCH INTERVIEW JSON RESPONSE");
    console.log("================================");

    const requirementId =
        await getLatestInterviewRequirement();

    console.log(
        `Latest Interview Requirement ID: ${requirementId}`
    );

    const interviewRequirement =
        await getWorkItem(requirementId);

    console.log("");
    console.log("================================");
    console.log("INTERVIEW REQUIREMENT JSON");
    console.log("================================");

    console.log(
        JSON.stringify(
            interviewRequirement,
            null,
            2
        )
    );

    const childTasks =
        (interviewRequirement.relations || [])
            .filter(
                relation =>
                    relation.rel ===
                    "System.LinkTypes.Hierarchy-Forward"
            );

    if (childTasks.length === 0) {

        console.log("");
        console.log(
            "No Interview Tasks linked to this Interview Requirement."
        );

        return;

    }

    for (const child of childTasks) {

        const taskId =
            child.url
                .split("/")
                .pop();

        const interviewTask =
            await getWorkItem(taskId);

        console.log("");
        console.log("================================");
        console.log(
            `INTERVIEW TASK JSON - ${taskId}`
        );
        console.log("================================");

        console.log(
            JSON.stringify(
                interviewTask,
                null,
                2
            )
        );

    }

}

run().catch(error => {

    console.error(error);

    process.exit(1);

});