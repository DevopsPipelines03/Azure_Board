const axios = require("axios");
 
const org = process.env.ADO_ORG;
const pat = process.env.ADO_PAT;
 
const auth = Buffer.from(`:${pat}`).toString("base64");
 
async function getProcesses() {
    try {
 
        const response = await axios.get(
            `https://dev.azure.com/${org}/_apis/work/processes?api-version=7.1-preview.2`,
            {
                headers: {
                    Authorization: `Basic ${auth}`
                }
            }
        );
 
        console.log("========== PROCESSES ==========");
 
        response.data.value.forEach(process => {
            console.log(`Name     : ${process.name}`);
            console.log(`ProcessId: ${process.typeId}`);
            console.log("--------------------------------");
        });
 
    } catch (error) {
 
        console.error(
            error.response?.data || error.message
        );
 
        process.exit(1);
    }
}
 
getProcesses();