// Be Careful: Email is from an External Source 
// Use caution when opening emails and do not click on links or attachments from unknown senders. For more resources, visit security.cat.com/phishing. 


// const fs = require("fs");
// const path = require("path");
// const axios = require("axios");

// const API_VERSION = "7.1";

// const ORGANIZATION = String(
//     process.env.ADO_ORG || ""
// ).trim();

// const PAT = String(
//     process.env.ADO_PAT || ""
// ).trim();

// const PROJECT = String(
//     process.env.ADO_PROJECT || ""
// ).trim();

// const ADO_URL = (
//     String(
//         process.env.ADO_URL ||
//         `https://dev.azure.com/${ORGANIZATION}`
//     ).trim()
// ).replace(/\/+$/, "");

// const SOURCE_PROCESS_ID = String(
//     process.env.SOURCE_PROCESS_ID || ""
// ).trim();

// const TARGET_PROCESS_ID = String(
//     process.env.TARGET_PROCESS_ID || ""
// ).trim();

// const MIGRATION_MODE = String(
//     process.env.MIGRATION_MODE || "dry-run"
// ).trim().toLowerCase();

// const CREATE_MISSING_WITS =
//     String(
//         process.env.CREATE_MISSING_WITS || "true"
//     )
//         .trim()
//         .toLowerCase() === "true";

// const SYNC_LAYOUT =
//     String(
//         process.env.SYNC_LAYOUT || "true"
//     )
//         .trim()
//         .toLowerCase() === "true";

// const CONFIG_DIR = path.join(
//     __dirname,
//     "..",
//     "config"
// );

// const REPORT_FILE = path.join(
//     CONFIG_DIR,
//     "migration-report.json"
// );

// const WIT_CONFIGS = [
//     "interview-evaluation.json",
//     "interview-task.json"
// ];


// /* ============================================================
//    VALIDATION
// ============================================================ */

// function validateEnvironment() {

//     const missing = [];

//     if (!ORGANIZATION) {
//         missing.push("ADO_ORG");
//     }

//     if (!PAT) {
//         missing.push("ADO_PAT");
//     }

//     if (!PROJECT) {
//         missing.push("ADO_PROJECT");
//     }

//     if (!SOURCE_PROCESS_ID) {
//         missing.push("SOURCE_PROCESS_ID");
//     }

//     if (!TARGET_PROCESS_ID) {
//         missing.push("TARGET_PROCESS_ID");
//     }

//     if (missing.length > 0) {

//         throw new Error(
//             `Missing environment variables: ${missing.join(", ")}`
//         );
//     }

//     if (
//         !["apply", "dry-run"].includes(
//             MIGRATION_MODE
//         )
//     ) {

//         throw new Error(
//             `Invalid MIGRATION_MODE '${MIGRATION_MODE}'. ` +
//             `Use 'apply' or 'dry-run'.`
//         );
//     }
// }


// /* ============================================================
//    AXIOS CLIENT
// ============================================================ */

// const api = axios.create({

//     baseURL: ADO_URL,

//     auth: {
//         username: "",
//         password: PAT
//     },

//     headers: {
//         Accept: "application/json",
//         "Content-Type": "application/json"
//     },

//     params: {
//         "api-version": API_VERSION
//     },

//     timeout: 120000
// });


// /* ============================================================
//    LOGGING
// ============================================================ */

// function log(message = "") {

//     console.log(
//         `[MIGRATE] ${message}`
//     );
// }


// function errorLog(message = "") {

//     console.error(
//         `[ERROR] ${message}`
//     );
// }


// function formatAxiosError(error) {

//     if (!error) {
//         return "Unknown error";
//     }

//     if (error.response) {

//         const status =
//             error.response.status ||
//             "unknown";

//         const data =
//             error.response.data;

//         let body;

//         try {

//             body =
//                 JSON.stringify(
//                     data,
//                     null,
//                     2
//                 );

//         } catch {

//             body =
//                 String(data);
//         }

//         return (
//             `HTTP ${status}\n${body}`
//         );
//     }

//     if (error.request) {

//         return (
//             "No response received from Azure DevOps."
//         );
//     }

//     return (
//         error.message ||
//         String(error)
//     );
// }


// /* ============================================================
//    HELPERS
// ============================================================ */

// function encode(value) {

//     return encodeURIComponent(
//         value
//     );
// }


// function clone(value) {

//     if (
//         value === undefined ||
//         value === null
//     ) {

//         return value;
//     }

//     return JSON.parse(
//         JSON.stringify(value)
//     );
// }


// function removeUndefined(object) {

//     return Object.fromEntries(
//         Object.entries(object)
//             .filter(
//                 ([, value]) =>
//                     value !== undefined
//             )
//     );
// }


// function sameName(a, b) {

//     return (
//         String(a || "")
//             .trim()
//             .toLowerCase()
//         ===
//         String(b || "")
//             .trim()
//             .toLowerCase()
//     );
// }


// function isCustomField(field) {

//     const referenceName =
//         String(
//             field?.referenceName || ""
//         )
//             .toLowerCase();

//     const customization =
//         String(
//             field?.customization || ""
//         )
//             .toLowerCase();

//     return (
//         referenceName.startsWith(
//             "custom."
//         ) ||
//         customization === "custom"
//     );
// }


// function isCustomControl(control) {

//     if (!control) {
//         return false;
//     }

//     const id =
//         String(
//             control.id || ""
//         );

//     return (
//         id.toLowerCase().startsWith(
//             "custom."
//         ) ||
//         control.inherited === false ||
//         control.overridden === true
//     );
// }


// /* ============================================================
//    AZURE DEVOPS PROCESS
// ============================================================ */

// async function getProcess(
//     processId
// ) {

//     const response =
//         await api.get(
//             `/_apis/work/processes/${encode(processId)}`
//         );

//     return response.data;
// }


// /* ============================================================
//    WORK ITEM TYPES
// ============================================================ */

// async function getWorkItemTypes(
//     processId
// ) {

//     const response =
//         await api.get(
//             `/_apis/work/processes/${encode(processId)}` +
//             `/workItemTypes`
//         );

//     return (
//         response.data?.value ||
//         []
//     );
// }


// async function findWit(
//     processId,
//     witName
// ) {

//     const wits =
//         await getWorkItemTypes(
//             processId
//         );

//     return wits.find(
//         wit =>
//             sameName(
//                 wit.name,
//                 witName
//             )
//     );
// }


// async function createWit(
//     witConfig
// ) {

//     const payload = {

//         name:
//             witConfig.workItemType.name,

//         description:
//             witConfig.workItemType.description ||
//             "",

//         color:
//             witConfig.workItemType.color ||
//             "009CCC",

//         icon:
//             witConfig.workItemType.icon ||
//             "icon_clipboard",

//         isDisabled: false,

//         inheritsFrom: null
//     };

//     log(
//         `Creating target WIT: ${payload.name}`
//     );

//     const response =
//         await api.post(
//             `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
//             `/workitemtypes`,
//             payload
//         );

//     return response.data;
// }


// async function resolveTargetWit(
//     witConfig
// ) {

//     const name =
//         witConfig.workItemType.name;

//     let target =
//         await findWit(
//             TARGET_PROCESS_ID,
//             name
//         );

//     if (target) {

//         log(
//             `Target WIT '${name}' -> '${target.referenceName}'`
//         );

//         return target;
//     }

//     if (!CREATE_MISSING_WITS) {

//         throw new Error(
//             `Target WIT '${name}' does not exist ` +
//             `and CREATE_MISSING_WITS=false.`
//         );
//     }

//     target =
//         await createWit(
//             witConfig
//         );

//     log(
//         `Created target WIT '${name}' -> '${target.referenceName}'`
//     );

//     return target;
// }


// /* ============================================================
//    WIT METADATA
// ============================================================ */

// async function updateWitMetadata(
//     targetWit,
//     witConfig
// ) {

//     const source =
//         witConfig.workItemType;

//     const payload =
//         removeUndefined({

//             name:
//                 source.name,

//             description:
//                 source.description,

//             color:
//                 source.color,

//             icon:
//                 source.icon,

//             isDisabled:
//                 source.isDisabled === true
//         });

//     if (
//         MIGRATION_MODE !== "apply"
//     ) {

//         log(
//             `[DRY-RUN] Would update WIT metadata: ${source.name}`
//         );

//         return;
//     }

//     await api.patch(
//         `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
//         `/workItemTypes/${encode(targetWit.referenceName)}`,
//         payload
//     );

//     log(
//         `Updated WIT metadata: ${source.name}`
//     );
// }


// /* ============================================================
//    FIELDS
// ============================================================ */

// async function getFields(
//     processId,
//     witReferenceName
// ) {

//     const response =
//         await api.get(
//             `/_apis/work/processes/${encode(processId)}` +
//             `/workItemTypes/${encode(witReferenceName)}/fields`
//         );

//     return (
//         response.data?.value ||
//         []
//     );
// }


// function normalizeAllowedValues(
//     values
// ) {

//     if (!Array.isArray(values)) {
//         return undefined;
//     }

//     const result =
//         values
//             .map(value => {

//                 if (
//                     value !== null &&
//                     typeof value === "object"
//                 ) {

//                     return (
//                         value.value ??
//                         value.name ??
//                         value.text ??
//                         null
//                     );
//                 }

//                 return value;
//             })
//             .filter(
//                 value =>
//                     value !== null &&
//                     value !== undefined
//             )
//             .map(
//                 value =>
//                     String(value)
//             );

//     return (
//         result.length > 0
//             ? result
//             : undefined
//     );
// }


// function buildFieldPayload(
//     sourceField
// ) {

//     return removeUndefined({

//         referenceName:
//             sourceField.referenceName,

//         required:
//             sourceField.required === true,

//         readOnly:
//             sourceField.readOnly === true,

//         allowGroups:
//             sourceField.allowGroups === true,

//         allowedValues:
//             normalizeAllowedValues(
//                 sourceField.allowedValues
//             ),

//         defaultValue:
//             sourceField.defaultValue
//     });
// }


// async function addField(
//     targetWit,
//     sourceField
// ) {

//     const payload =
//         buildFieldPayload(
//             sourceField
//         );

//     if (
//         MIGRATION_MODE !== "apply"
//     ) {

//         log(
//             `[DRY-RUN] Would add field: ${sourceField.referenceName}`
//         );

//         return;
//     }

//     await api.post(
//         `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
//         `/workItemTypes/${encode(targetWit.referenceName)}/fields`,
//         payload
//     );

//     log(
//         `Added field: ${sourceField.referenceName}`
//     );
// }


// async function updateExistingField(
//     targetWit,
//     sourceField
// ) {

//     const fieldRef =
//         sourceField.referenceName;

//     const payload =
//         removeUndefined({

//             required:
//                 sourceField.required === true,

//             readOnly:
//                 sourceField.readOnly === true,

//             allowGroups:
//                 sourceField.allowGroups === true,

//             allowedValues:
//                 normalizeAllowedValues(
//                     sourceField.allowedValues
//                 ),

//             defaultValue:
//                 sourceField.defaultValue
//         });

//     if (
//         MIGRATION_MODE !== "apply"
//     ) {

//         log(
//             `[DRY-RUN] Would update field: ${fieldRef}`
//         );

//         return;
//     }

//     await api.patch(
//         `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
//         `/workItemTypes/${encode(targetWit.referenceName)}` +
//         `/fields/${encode(fieldRef)}`,
//         payload
//     );

//     log(
//         `Updated field: ${fieldRef}`
//     );
// }


// async function migrateFields(
//     targetWit,
//     sourceFields
// ) {

//     const targetFields =
//         await getFields(
//             TARGET_PROCESS_ID,
//             targetWit.referenceName
//         );

//     log(
//         `Source custom fields: ${sourceFields.length}`
//     );

//     log(
//         `Target fields: ${targetFields.length}`
//     );

//     const targetMap =
//         new Map();

//     for (
//         const field
//         of targetFields
//     ) {

//         targetMap.set(
//             String(
//                 field.referenceName
//             )
//                 .toLowerCase(),
//             field
//         );
//     }

//     let added = 0;
//     let updated = 0;
//     let failed = 0;

//     for (
//         const sourceField
//         of sourceFields
//     ) {

//         if (
//             !isCustomField(
//                 sourceField
//             )
//         ) {
//             continue;
//         }

//         const key =
//             String(
//                 sourceField.referenceName
//             )
//                 .toLowerCase();

//         const targetField =
//             targetMap.get(key);

//         try {

//             if (targetField) {

//                 await updateExistingField(
//                     targetWit,
//                     sourceField
//                 );

//                 updated++;

//             } else {

//                 await addField(
//                     targetWit,
//                     sourceField
//                 );

//                 added++;
//             }

//         } catch (error) {

//             failed++;

//             errorLog(
//                 `Failed field '${sourceField.referenceName}'`
//             );

//             errorLog(
//                 formatAxiosError(
//                     error
//                 )
//             );
//         }
//     }

//     return {

//         source:
//             sourceFields.length,

//         target:
//             targetFields.length,

//         added,

//         updated,

//         failed
//     };
// }


// /* ============================================================
//    STATES
// ============================================================ */

// async function getStates(
//     processId,
//     witReferenceName
// ) {

//     const response =
//         await api.get(
//             `/_apis/work/processes/${encode(processId)}` +
//             `/workItemTypes/${encode(witReferenceName)}/states`
//         );

//     return (
//         response.data?.value ||
//         []
//     );
// }


// const STATE_CATEGORY_ORDER = {

//     Proposed: 1,

//     InProgress: 2,

//     Resolved: 3,

//     Completed: 4,

//     Removed: 5
// };


// function normalizeStateCategory(
//     category
// ) {

//     const value =
//         String(category || "")
//             .replace(/\s+/g, "")
//             .toLowerCase();

//     if (
//         value === "proposed"
//     ) {
//         return "Proposed";
//     }

//     if (
//         value === "inprogress" ||
//         value === "in-progress"
//     ) {
//         return "InProgress";
//     }

//     if (
//         value === "resolved"
//     ) {
//         return "Resolved";
//     }

//     if (
//         value === "completed" ||
//         value === "complete"
//     ) {
//         return "Completed";
//     }

//     if (
//         value === "removed"
//     ) {
//         return "Removed";
//     }

//     return "Proposed";
// }


// function getCategoryRank(
//     state
// ) {

//     const category =
//         normalizeStateCategory(
//             state.stateCategory
//         );

//     return (
//         STATE_CATEGORY_ORDER[
//             category
//         ] || 99
//     );
// }


// function calculateValidStateOrder(
//     states,
//     desiredState
// ) {

//     const category =
//         normalizeStateCategory(
//             desiredState.stateCategory
//         );

//     const categoryStates =
//         states
//             .filter(
//                 state =>
//                     normalizeStateCategory(
//                         state.stateCategory
//                     ) === category
//             )
//             .sort(
//                 (a, b) =>
//                     Number(
//                         a.order || 0
//                     ) -
//                     Number(
//                         b.order || 0
//                     )
//             );

//     if (
//         categoryStates.length === 0
//     ) {

//         return (
//             STATE_CATEGORY_ORDER[
//                 category
//             ] || 1
//         );
//     }

//     const maxOrder =
//         Math.max(
//             ...categoryStates.map(
//                 state =>
//                     Number(
//                         state.order || 0
//                     )
//             )
//         );

//     return (
//         maxOrder + 1
//     );
// }


// async function updateExistingState(
//     targetWit,
//     sourceState,
//     targetState
// ) {

//     /*
//      * IMPORTANT:
//      *
//      * Do NOT send:
//      *   order
//      *   stateCategory
//      *
//      * for an existing target state.
//      *
//      * Azure DevOps validates those values against
//      * the complete target workflow.
//      */

//     const payload = {

//         name:
//             sourceState.name,

//         color:
//             sourceState.color ||
//             targetState.color ||
//             "B2B2B2"
//     };

//     if (
//         MIGRATION_MODE !== "apply"
//     ) {

//         log(
//             `[DRY-RUN] Would safely update state: ${sourceState.name}`
//         );

//         return;
//     }

//     await api.patch(
//         `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
//         `/workItemTypes/${encode(targetWit.referenceName)}` +
//         `/states/${encode(targetState.id)}`,
//         payload
//     );

//     log(
//         `Updated state safely: ${sourceState.name}`
//     );
// }


// async function createMissingState(
//     targetWit,
//     sourceState,
//     targetStates
// ) {

//     const category =
//         normalizeStateCategory(
//             sourceState.stateCategory
//         );

//     const order =
//         calculateValidStateOrder(
//             targetStates,
//             sourceState
//         );

//     const payload = {

//         name:
//             sourceState.name,

//         color:
//             sourceState.color ||
//             "B2B2B2",

//         stateCategory:
//             category,

//         order:
//             order
//     };

//     if (
//         MIGRATION_MODE !== "apply"
//     ) {

//         log(
//             `[DRY-RUN] Would create state: ` +
//             `${sourceState.name} ` +
//             `(category=${category}, order=${order})`
//         );

//         return;
//     }

//     try {

//         await api.post(
//             `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
//             `/workItemTypes/${encode(targetWit.referenceName)}/states`,
//             payload
//         );

//         log(
//             `Created state: ${sourceState.name} ` +
//             `(category=${category}, order=${order})`
//         );

//     } catch (error) {

//         /*
//          * Azure DevOps can reject the explicit order.
//          *
//          * Retry without order.
//          */

//         if (
//             error.response &&
//             error.response.status === 400
//         ) {

//             log(
//                 `Retrying state '${sourceState.name}' ` +
//                 `without explicit order`
//             );

//             const retryPayload = {

//                 name:
//                     sourceState.name,

//                 color:
//                     sourceState.color ||
//                     "B2B2B2",

//                 stateCategory:
//                     category
//             };

//             await api.post(
//                 `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
//                 `/workItemTypes/${encode(targetWit.referenceName)}/states`,
//                 retryPayload
//             );

//             log(
//                 `Created state on retry: ${sourceState.name}`
//             );

//             return;
//         }

//         throw error;
//     }
// }


// async function migrateStates(
//     targetWit,
//     sourceStates
// ) {

//     let targetStates =
//         await getStates(
//             TARGET_PROCESS_ID,
//             targetWit.referenceName
//         );

//     log(
//         `Source states: ${sourceStates.length}`
//     );

//     log(
//         `Target states: ${targetStates.length}`
//     );

//     let updated = 0;
//     let created = 0;
//     let skipped = 0;
//     let failed = 0;

//     const orderedSourceStates =
//         [...sourceStates]
//             .sort(
//                 (a, b) => {

//                     const categoryA =
//                         getCategoryRank(a);

//                     const categoryB =
//                         getCategoryRank(b);

//                     if (
//                         categoryA !==
//                         categoryB
//                     ) {

//                         return (
//                             categoryA -
//                             categoryB
//                         );
//                     }

//                     return (
//                         Number(
//                             a.order || 0
//                         ) -
//                         Number(
//                             b.order || 0
//                         )
//                     );
//                 }
//             );

//     for (
//         const sourceState
//         of orderedSourceStates
//     ) {

//         try {

//             const targetState =
//                 targetStates.find(
//                     state =>
//                         sameName(
//                             state.name,
//                             sourceState.name
//                         )
//                 );

//             if (targetState) {

//                 await updateExistingState(
//                     targetWit,
//                     sourceState,
//                     targetState
//                 );

//                 updated++;

//             } else {

//                 await createMissingState(
//                     targetWit,
//                     sourceState,
//                     targetStates
//                 );

//                 created++;

//                 targetStates =
//                     await getStates(
//                         TARGET_PROCESS_ID,
//                         targetWit.referenceName
//                     );
//             }

//         } catch (error) {

//             failed++;

//             errorLog(
//                 `Failed state '${sourceState.name}'`
//             );

//             errorLog(
//                 formatAxiosError(
//                     error
//                 )
//             );
//         }
//     }

//     return {

//         source:
//             sourceStates.length,

//         target:
//             targetStates.length,

//         updated,

//         created,

//         skipped,

//         failed
//     };
// }


// /* ============================================================
//    RULES
// ============================================================ */

// async function getRules(
//     processId,
//     witReferenceName
// ) {

//     const response =
//         await api.get(
//             `/_apis/work/processes/${encode(processId)}` +
//             `/workItemTypes/${encode(witReferenceName)}/rules`
//         );

//     return (
//         response.data?.value ||
//         []
//     );
// }


// function normalizeRule(
//     rule
// ) {

//     const result =
//         clone(rule);

//     delete result.id;
//     delete result.url;
//     delete result._links;

//     return result;
// }


// async function migrateRules(
//     targetWit,
//     sourceRules
// ) {

//     const targetRules =
//         await getRules(
//             TARGET_PROCESS_ID,
//             targetWit.referenceName
//         );

//     log(
//         `Source rules: ${sourceRules.length}`
//     );

//     log(
//         `Target rules: ${targetRules.length}`
//     );

//     let created = 0;
//     let skipped = 0;
//     let failed = 0;

//     for (
//         const sourceRule
//         of sourceRules
//     ) {

//         try {

//             const existingRule =
//                 targetRules.find(
//                     rule =>
//                         sameName(
//                             rule.name,
//                             sourceRule.name
//                         )
//                 );

//             if (existingRule) {

//                 log(
//                     `Rule already exists: ${sourceRule.name}`
//                 );

//                 skipped++;

//                 continue;
//             }

//             const payload =
//                 normalizeRule(
//                     sourceRule
//                 );

//             if (
//                 MIGRATION_MODE !== "apply"
//             ) {

//                 log(
//                     `[DRY-RUN] Would create rule: ${sourceRule.name}`
//                 );

//                 created++;

//                 continue;
//             }

//             try {

//                 await api.post(
//                     `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
//                     `/workItemTypes/${encode(targetWit.referenceName)}/rules`,
//                     payload
//                 );

//                 log(
//                     `Created rule: ${sourceRule.name}`
//                 );

//                 created++;

//             } catch (error) {

//                 /*
//                  * 304 is not a migration failure.
//                  */

//                 if (
//                     error.response &&
//                     error.response.status === 304
//                 ) {

//                     log(
//                         `Rule not modified: ${sourceRule.name}`
//                     );

//                     skipped++;

//                     continue;
//                 }

//                 throw error;
//             }

//         } catch (error) {

//             failed++;

//             errorLog(
//                 `Failed rule '${sourceRule.name}'`
//             );

//             errorLog(
//                 formatAxiosError(
//                     error
//                 )
//             );
//         }
//     }

//     return {

//         source:
//             sourceRules.length,

//         target:
//             targetRules.length,

//         created,

//         skipped,

//         failed
//     };
// }


// /* ============================================================
//    LAYOUT HELPERS
// ============================================================ */

// async function getLayout(
//     processId,
//     witReferenceName
// ) {

//     const response =
//         await api.get(
//             `/_apis/work/processes/${encode(processId)}` +
//             `/workItemTypes/${encode(witReferenceName)}/layout`
//         );

//     return response.data;
// }


// function hasMigratableControls(
//     section
// ) {

//     return (
//         section?.groups || []
//     ).some(
//         group =>
//             hasMigratableGroup(
//                 group
//             )
//     );
// }


// function hasMigratableGroup(
//     group
// ) {

//     if (!group) {
//         return false;
//     }

//     if (
//         group.inherited === false ||
//         group.overridden === true
//     ) {

//         return true;
//     }

//     return (
//         group.controls || []
//     ).some(
//         control =>
//             isCustomControl(
//                 control
//             )
//     );
// }


// function isMigratablePage(
//     page
// ) {

//     if (!page) {
//         return false;
//     }

//     if (
//         page.pageType === "custom" ||
//         page.inherited === false ||
//         page.overridden === true
//     ) {

//         return true;
//     }

//     return (
//         page.sections || []
//     ).some(
//         section =>
//             hasMigratableControls(
//                 section
//             )
//     );
// }


// function findPage(
//     layout,
//     sourcePage
// ) {

//     const pages =
//         layout?.pages || [];

//     /*
//      * First try ID.
//      */

//     if (sourcePage.id) {

//         const byId =
//             pages.find(
//                 page =>
//                     page.id ===
//                     sourcePage.id
//             );

//         if (byId) {
//             return byId;
//         }
//     }

//     /*
//      * Then match by label.
//      */

//     return pages.find(
//         page =>
//             sameName(
//                 page.label,
//                 sourcePage.label
//             )
//     );
// }


// function findSection(
//     page,
//     sourceSection
// ) {

//     const sections =
//         page?.sections || [];

//     if (
//         sourceSection.id
//     ) {

//         const byId =
//             sections.find(
//                 section =>
//                     section.id ===
//                     sourceSection.id
//             );

//         if (byId) {
//             return byId;
//         }
//     }

//     /*
//      * Section objects generally do not have
//      * a friendly label.
//      *
//      * If the source section ID cannot be found,
//      * fall back to position.
//      */

//     return (
//         sections[0] ||
//         null
//     );
// }


// function findGroup(
//     section,
//     sourceGroup
// ) {

//     const groups =
//         section?.groups || [];

//     if (
//         sourceGroup.id
//     ) {

//         const byId =
//             groups.find(
//                 group =>
//                     group.id ===
//                     sourceGroup.id
//             );

//         if (byId) {
//             return byId;
//         }
//     }

//     return groups.find(
//         group =>
//             sameName(
//                 group.label,
//                 sourceGroup.label
//             )
//     );
// }


// function findControl(
//     group,
//     sourceControl
// ) {

//     const controls =
//         group?.controls || [];

//     if (
//         sourceControl.id
//     ) {

//         const byId =
//             controls.find(
//                 control =>
//                     String(
//                         control.id || ""
//                     )
//                         .toLowerCase()
//                     ===
//                     String(
//                         sourceControl.id || ""
//                     )
//                         .toLowerCase()
//             );

//         if (byId) {
//             return byId;
//         }
//     }

//     return controls.find(
//         control =>
//             sameName(
//                 control.label,
//                 sourceControl.label
//             )
//     );
// }


// /* ============================================================
//    PAGE PAYLOAD
// ============================================================ */

// /*
// * IMPORTANT
// *
// * DO NOT include "sections" here.
// *
// * This is the direct fix for:
// *
// *   The value specified for the following variable
// *   must be null: Sections.
// *
// * Pages are handled separately from their child
// * layout components.
// */

// function buildPagePayload(
//     sourcePage,
//     targetPage
// ) {

//     return removeUndefined({

//         id:
//             targetPage?.id ||
//             undefined,

//         label:
//             sourcePage.label,

//         order:
//             sourcePage.order,

//         pageType:
//             sourcePage.pageType ||
//             "custom",

//         visible:
//             sourcePage.visible !== false,

//         locked:
//             sourcePage.locked === true,

//         isContribution:
//             sourcePage.isContribution === true,

//         contribution:
//             sourcePage.contribution
//     });
// }


// /* ============================================================
//    GROUP PAYLOAD
// ============================================================ */

// function buildGroupPayload(
//     sourceGroup,
//     targetGroup
// ) {

//     return removeUndefined({

//         id:
//             targetGroup?.id ||
//             undefined,

//         label:
//             sourceGroup.label,

//         order:
//             sourceGroup.order,

//         visible:
//             sourceGroup.visible !== false,

//         height:
//             sourceGroup.height,

//         isContribution:
//             sourceGroup.isContribution === true,

//         contribution:
//             sourceGroup.contribution
//     });
// }


// /* ============================================================
//    CONTROL PAYLOAD
// ============================================================ */

// function buildControlPayload(
//     sourceControl,
//     targetControl
// ) {

//     return removeUndefined({

//         id:
//             targetControl?.id ||
//             (
//                 isCustomControl(
//                     sourceControl
//                 )
//                     ? sourceControl.id
//                     : undefined
//             ),

//         label:
//             sourceControl.label,

//         order:
//             sourceControl.order,

//         controlType:
//             sourceControl.controlType,

//         visible:
//             sourceControl.visible !== false,

//         readOnly:
//             sourceControl.readOnly === true,

//         watermark:
//             sourceControl.watermark,

//         metadata:
//             sourceControl.metadata,

//         height:
//             sourceControl.height,

//         isContribution:
//             sourceControl.isContribution === true,

//         contribution:
//             sourceControl.contribution
//     });
// }


// /* ============================================================
//    PAGE MIGRATION
// ============================================================ */

// async function addOrUpdatePage(
//     targetWit,
//     sourcePage,
//     targetLayout
// ) {

//     const targetPage =
//         findPage(
//             targetLayout,
//             sourcePage
//         );

//     const payload =
//         buildPagePayload(
//             sourcePage,
//             targetPage
//         );

//     /*
//      * --------------------------------------------------------
//      * CREATE PAGE
//      * --------------------------------------------------------
//      */

//     if (!targetPage) {

//         if (
//             MIGRATION_MODE !== "apply"
//         ) {

//             log(
//                 `[DRY-RUN] Would create page: ${sourcePage.label}`
//             );

//             return null;
//         }

//         const response =
//             await api.post(
//                 `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
//                 `/workItemTypes/${encode(targetWit.referenceName)}` +
//                 `/layout/pages`,
//                 payload
//             );

//         log(
//             `Created page: ${sourcePage.label}`
//         );

//         return response.data;
//     }

//     /*
//      * --------------------------------------------------------
//      * UPDATE PAGE
//      * --------------------------------------------------------
//      */

//     if (
//         MIGRATION_MODE !== "apply"
//     ) {

//         log(
//             `[DRY-RUN] Would update page: ${sourcePage.label}`
//         );

//         return targetPage;
//     }

//     const response =
//         await api.patch(
//             `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
//             `/workItemTypes/${encode(targetWit.referenceName)}` +
//             `/layout/pages`,
//             payload
//         );

//     log(
//         `Updated page: ${sourcePage.label}`
//     );

//     return response.data;
// }


// /* ============================================================
//    GROUP MIGRATION
// ============================================================ */

// async function addOrUpdateGroup(
//     targetWit,
//     sourceGroup,
//     targetPage,
//     targetSection
// ) {

//     const targetGroup =
//         findGroup(
//             targetSection,
//             sourceGroup
//         );

//     const payload =
//         buildGroupPayload(
//             sourceGroup,
//             targetGroup
//         );

//     /*
//      * --------------------------------------------------------
//      * CREATE GROUP
//      * --------------------------------------------------------
//      */

//     if (!targetGroup) {

//         if (
//             MIGRATION_MODE !== "apply"
//         ) {

//             log(
//                 `[DRY-RUN] Would create group: ${sourceGroup.label}`
//             );

//             return null;
//         }

//         const response =
//             await api.post(
//                 `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
//                 `/workItemTypes/${encode(targetWit.referenceName)}` +
//                 `/layout/pages/${encode(targetPage.id)}` +
//                 `/sections/${encode(targetSection.id)}` +
//                 `/groups`,
//                 payload
//             );

//         log(
//             `Created group: ${sourceGroup.label}`
//         );

//         return response.data;
//     }

//     /*
//      * --------------------------------------------------------
//      * UPDATE GROUP
//      * --------------------------------------------------------
//      */

//     if (
//         MIGRATION_MODE !== "apply"
//     ) {

//         log(
//             `[DRY-RUN] Would update group: ${sourceGroup.label}`
//         );

//         return targetGroup;
//     }

//     const response =
//         await api.patch(
//             `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
//             `/workItemTypes/${encode(targetWit.referenceName)}` +
//             `/layout/pages/${encode(targetPage.id)}` +
//             `/sections/${encode(targetSection.id)}` +
//             `/groups/${encode(targetGroup.id)}`,
//             payload
//         );

//     log(
//         `Updated group: ${sourceGroup.label}`
//     );

//     return response.data;
// }


// /* ============================================================
//    CONTROL MIGRATION
// ============================================================ */

// async function addOrUpdateControl(
//     targetWit,
//     sourceControl,
//     targetGroup
// ) {

//     const targetControl =
//         findControl(
//             targetGroup,
//             sourceControl
//         );

//     const payload =
//         buildControlPayload(
//             sourceControl,
//             targetControl
//         );

//     /*
//      * --------------------------------------------------------
//      * CREATE CONTROL
//      * --------------------------------------------------------
//      */

//     if (!targetControl) {

//         if (
//             MIGRATION_MODE !== "apply"
//         ) {

//             log(
//                 `[DRY-RUN] Would create control: ${sourceControl.label}`
//             );

//             return;
//         }

//         await api.post(
//             `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
//             `/workItemTypes/${encode(targetWit.referenceName)}` +
//             `/layout/groups/${encode(targetGroup.id)}/controls`,
//             payload
//         );

//         log(
//             `Created control: ${sourceControl.label}`
//         );

//         return;
//     }

//     /*
//      * --------------------------------------------------------
//      * UPDATE CONTROL
//      * --------------------------------------------------------
//      */

//     if (
//         MIGRATION_MODE !== "apply"
//     ) {

//         log(
//             `[DRY-RUN] Would update control: ${sourceControl.label}`
//         );

//         return;
//     }

//     await api.patch(
//         `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
//         `/workItemTypes/${encode(targetWit.referenceName)}` +
//         `/layout/groups/${encode(targetGroup.id)}` +
//         `/controls/${encode(targetControl.id)}`,
//         payload
//     );

//     log(
//         `Updated control: ${sourceControl.label}`
//     );
// }


// /* ============================================================
//    LAYOUT MIGRATION
// ============================================================ */

// async function migrateLayout(
//     targetWit,
//     sourceLayout
// ) {

//     if (!SYNC_LAYOUT) {

//         log(
//             "Layout synchronization disabled."
//         );

//         return {
//             skipped: true
//         };
//     }

//     if (!sourceLayout) {

//         log(
//             "No source layout found."
//         );

//         return {
//             skipped: true
//         };
//     }

//     log(
//         "Starting layout synchronization..."
//     );

//     let targetLayout =
//         await getLayout(
//             TARGET_PROCESS_ID,
//             targetWit.referenceName
//         );

//     const sourcePages =
//         sourceLayout.pages ||
//         [];

//     let pagesProcessed = 0;
//     let groupsProcessed = 0;
//     let controlsProcessed = 0;
//     let failed = 0;

//     for (
//         const sourcePage
//         of sourcePages
//     ) {

//         /*
//          * Never attempt to modify the inherited
//          * History / Links / Attachments pages.
//          */

//         if (
//             !isMigratablePage(
//                 sourcePage
//             )
//         ) {

//             log(
//                 `Skipping inherited page: ${sourcePage.label}`
//             );

//             continue;
//         }

//         try {

//             /*
//              * ------------------------------------------------
//              * STEP 1: PAGE
//              * ------------------------------------------------
//              */

//             await addOrUpdatePage(
//                 targetWit,
//                 sourcePage,
//                 targetLayout
//             );

//             pagesProcessed++;

//             /*
//              * Refresh layout after page operation.
//              */

//             targetLayout =
//                 await getLayout(
//                     TARGET_PROCESS_ID,
//                     targetWit.referenceName
//                 );

//             const targetPage =
//                 findPage(
//                     targetLayout,
//                     sourcePage
//                 );

//             if (!targetPage) {

//                 failed++;

//                 errorLog(
//                     `Could not resolve target page after update: ${sourcePage.label}`
//                 );

//                 continue;
//             }

//             /*
//              * ------------------------------------------------
//              * STEP 2: SECTIONS / GROUPS
//              * ------------------------------------------------
//              */

//             const sourceSections =
//                 sourcePage.sections ||
//                 [];

//             const targetSections =
//                 targetPage.sections ||
//                 [];

//             for (
//                 let sectionIndex = 0;
//                 sectionIndex < sourceSections.length;
//                 sectionIndex++
//             ) {

//                 const sourceSection =
//                     sourceSections[
//                         sectionIndex
//                     ];

//                 /*
//                  * Find by ID first.
//                  */

//                 let targetSection =
//                     null;

//                 if (
//                     sourceSection.id
//                 ) {

//                     targetSection =
//                         targetSections.find(
//                             section =>
//                                 section.id ===
//                                 sourceSection.id
//                         );
//                 }

//                 /*
//                  * If ID does not match, use the
//                  * section's position.
//                  */

//                 if (!targetSection) {

//                     targetSection =
//                         targetSections[
//                             sectionIndex
//                         ];
//                 }

//                 if (!targetSection) {

//                     errorLog(
//                         `Could not resolve section ${sectionIndex} ` +
//                         `for page '${sourcePage.label}'`
//                     );

//                     failed++;

//                     continue;
//                 }

//                 /*
//                  * The section API object doesn't need
//                  * a locally injected pageId anymore.
//                  *
//                  * We pass targetPage explicitly.
//                  */

//                 const sourceGroups =
//                     sourceSection.groups ||
//                     [];

//                 for (
//                     const sourceGroup
//                     of sourceGroups
//                 ) {

//                     if (
//                         !hasMigratableGroup(
//                             sourceGroup
//                         )
//                     ) {

//                         continue;
//                     }

//                     try {

//                         /*
//                          * ------------------------------------------------
//                          * STEP 3: GROUP
//                          * ------------------------------------------------
//                          */

//                         const targetGroup =
//                             await addOrUpdateGroup(
//                                 targetWit,
//                                 sourceGroup,
//                                 targetPage,
//                                 targetSection
//                             );

//                         groupsProcessed++;

//                         if (
//                             MIGRATION_MODE !== "apply"
//                         ) {

//                             continue;
//                         }

//                         /*
//                          * Refresh the complete layout after
//                          * group creation/update.
//                          */

//                         targetLayout =
//                             await getLayout(
//                                 TARGET_PROCESS_ID,
//                                 targetWit.referenceName
//                             );

//                         const refreshedPage =
//                             findPage(
//                                 targetLayout,
//                                 sourcePage
//                             );

//                         if (!refreshedPage) {

//                             errorLog(
//                                 `Could not resolve refreshed page: ${sourcePage.label}`
//                             );

//                             failed++;

//                             continue;
//                         }

//                         const refreshedSections =
//                             refreshedPage.sections ||
//                             [];

//                         let refreshedSection =
//                             null;

//                         if (
//                             sourceSection.id
//                         ) {

//                             refreshedSection =
//                                 refreshedSections.find(
//                                     section =>
//                                         section.id ===
//                                         sourceSection.id
//                                 );
//                         }

//                         if (!refreshedSection) {

//                             refreshedSection =
//                                 refreshedSections[
//                                     sectionIndex
//                                 ];
//                         }

//                         if (!refreshedSection) {

//                             errorLog(
//                                 `Could not resolve refreshed section ` +
//                                 `for page '${sourcePage.label}'`
//                             );

//                             failed++;

//                             continue;
//                         }

//                         const refreshedGroup =
//                             findGroup(
//                                 refreshedSection,
//                                 sourceGroup
//                             );

//                         if (!refreshedGroup) {

//                             errorLog(
//                                 `Could not resolve target group: ${sourceGroup.label}`
//                             );

//                             failed++;

//                             continue;
//                         }

//                         /*
//                          * ------------------------------------------------
//                          * STEP 4: CONTROLS
//                          * ------------------------------------------------
//                          */

//                         for (
//                             const sourceControl
//                             of sourceGroup.controls || []
//                         ) {

//                             /*
//                              * We intentionally migrate custom/
//                              * overridden controls only.
//                              *
//                              * Standard inherited controls remain
//                              * supplied by the target process.
//                              */

//                             if (
//                                 !isCustomControl(
//                                     sourceControl
//                                 )
//                             ) {

//                                 continue;
//                             }

//                             try {

//                                 await addOrUpdateControl(
//                                     targetWit,
//                                     sourceControl,
//                                     refreshedGroup
//                                 );

//                                 controlsProcessed++;

//                             } catch (error) {

//                                 failed++;

//                                 errorLog(
//                                     `Failed control '${sourceControl.label}'`
//                                 );

//                                 errorLog(
//                                     formatAxiosError(
//                                         error
//                                     )
//                                 );
//                             }
//                         }

//                     } catch (error) {

//                         failed++;

//                         errorLog(
//                             `Failed group '${sourceGroup.label}'`
//                         );

//                         errorLog(
//                             formatAxiosError(
//                                 error
//                             )
//                         );
//                     }
//                 }
//             }

//         } catch (error) {

//             failed++;

//             errorLog(
//                 `Failed page '${sourcePage.label}'`
//             );

//             errorLog(
//                 formatAxiosError(
//                     error
//                 )
//             );
//         }
//     }

//     log(
//         `Layout synchronization completed. ` +
//         `Pages=${pagesProcessed}, ` +
//         `Groups=${groupsProcessed}, ` +
//         `Controls=${controlsProcessed}, ` +
//         `Failures=${failed}`
//     );

//     return {

//         skipped: false,

//         pagesProcessed,

//         groupsProcessed,

//         controlsProcessed,

//         failed
//     };
// }


// /* ============================================================
//    CONFIGURATION
// ============================================================ */

// function loadConfig(
//     fileName
// ) {

//     const filePath =
//         path.join(
//             CONFIG_DIR,
//             fileName
//         );

//     if (
//         !fs.existsSync(
//             filePath
//         )
//     ) {

//         throw new Error(
//             `Configuration file not found: ${filePath}`
//         );
//     }

//     return JSON.parse(
//         fs.readFileSync(
//             filePath,
//             "utf8"
//         )
//     );
// }


// /* ============================================================
//    REPORT
// ============================================================ */

// const report = {

//     startedAt:
//         new Date().toISOString(),

//     organization:
//         ORGANIZATION,

//     project:
//         PROJECT,

//     sourceProcessId:
//         SOURCE_PROCESS_ID,

//     targetProcessId:
//         TARGET_PROCESS_ID,

//     migrationMode:
//         MIGRATION_MODE,

//     createMissingWits:
//         CREATE_MISSING_WITS,

//     syncLayout:
//         SYNC_LAYOUT,

//     workItemTypes: [],

//     success: false,

//     completedAt: null
// };


// function saveReport() {

//     report.completedAt =
//         new Date().toISOString();

//     fs.mkdirSync(
//         CONFIG_DIR,
//         {
//             recursive: true
//         }
//     );

//     fs.writeFileSync(
//         REPORT_FILE,
//         JSON.stringify(
//             report,
//             null,
//             2
//         )
//     );

//     log(
//         `Migration report: ${REPORT_FILE}`
//     );
// }


// /* ============================================================
//    MIGRATE ONE WIT
// ============================================================ */

// async function migrateWit(
//     configFile
// ) {

//     const config =
//         loadConfig(
//             configFile
//         );

//     const witName =
//         config.workItemType.name;

//     const witReport = {

//         file:
//             configFile,

//         name:
//             witName,

//         targetReferenceName:
//             null,

//         success:
//             false,

//         fields:
//             null,

//         states:
//             null,

//         rules:
//             null,

//         layout:
//             null,

//         errors:
//             []
//     };

//     report.workItemTypes.push(
//         witReport
//     );

//     log("");

//     log(
//         "============================================================"
//     );

//     log(
//         `Migrating WIT: ${witName}`
//     );

//     log(
//         "============================================================"
//     );

//     try {

//         /*
//          * ------------------------------------------------------
//          * Validate exported source process
//          * ------------------------------------------------------
//          */

//         if (
//             config.source &&
//             config.source.processId &&
//             String(
//                 config.source.processId
//             ) !== SOURCE_PROCESS_ID
//         ) {

//             throw new Error(
//                 `Source process mismatch for ${witName}. ` +
//                 `Config=${config.source.processId}, ` +
//                 `Pipeline=${SOURCE_PROCESS_ID}`
//             );
//         }

//         /*
//          * ------------------------------------------------------
//          * Resolve target WIT
//          * ------------------------------------------------------
//          */

//         const targetWit =
//             await resolveTargetWit(
//                 config
//             );

//         witReport.targetReferenceName =
//             targetWit.referenceName;

//         /*
//          * ------------------------------------------------------
//          * WIT METADATA
//          * ------------------------------------------------------
//          */

//         await updateWitMetadata(
//             targetWit,
//             config
//         );

//         /*
//          * ------------------------------------------------------
//          * FIELDS
//          * ------------------------------------------------------
//          */

//         witReport.fields =
//             await migrateFields(
//                 targetWit,
//                 config.customFields ||
//                 []
//             );

//         /*
//          * ------------------------------------------------------
//          * STATES
//          * ------------------------------------------------------
//          */

//         witReport.states =
//             await migrateStates(
//                 targetWit,
//                 config.states ||
//                 []
//             );

//         /*
//          * ------------------------------------------------------
//          * RULES
//          * ------------------------------------------------------
//          */

//         witReport.rules =
//             await migrateRules(
//                 targetWit,
//                 config.rules ||
//                 []
//             );

//         /*
//          * ------------------------------------------------------
//          * LAYOUT
//          * ------------------------------------------------------
//          */

//         witReport.layout =
//             await migrateLayout(
//                 targetWit,
//                 config.layout
//             );

//         /*
//          * ------------------------------------------------------
//          * WIT COMPLETE
//          * ------------------------------------------------------
//          *
//          * Component-level errors are already recorded.
//          * The WIT itself is successful if its migration
//          * reached this point without an unexpected fatal
//          * exception.
//          */

//         witReport.success =
//             true;

//         log(
//             `Completed WIT: ${witName}`
//         );

//         return true;

//     } catch (error) {

//         witReport.success =
//             false;

//         const message =
//             formatAxiosError(
//                 error
//             );

//         witReport.errors.push(
//             message
//         );

//         errorLog(
//             `Migration failed for ${configFile}`
//         );

//         errorLog(
//             message
//         );

//         return false;
//     }
// }


// /* ============================================================
//    MAIN
// ============================================================ */

// async function main() {

//     validateEnvironment();

//     log("");

//     log(
//         "============================================================"
//     );

//     log(
//         "AZURE DEVOPS PROCESS MIGRATION"
//     );

//     log(
//         "============================================================"
//     );

//     log(
//         `Organization : ${ORGANIZATION}`
//     );

//     log(
//         `Project      : ${PROJECT}`
//     );

//     log(
//         `Source PID   : ${SOURCE_PROCESS_ID}`
//     );

//     log(
//         `Target PID   : ${TARGET_PROCESS_ID}`
//     );

//     log(
//         `Mode         : ${MIGRATION_MODE.toUpperCase()}`
//     );

//     log(
//         `Create WITs  : ${CREATE_MISSING_WITS}`
//     );

//     log(
//         `Sync Layout  : ${SYNC_LAYOUT}`
//     );

//     log("");

//     /*
//      * ----------------------------------------------------------
//      * Validate source and target processes
//      * ----------------------------------------------------------
//      */

//     const sourceProcess =
//         await getProcess(
//             SOURCE_PROCESS_ID
//         );

//     const targetProcess =
//         await getProcess(
//             TARGET_PROCESS_ID
//         );

//     log(
//         `Source process: ${sourceProcess.name}`
//     );

//     log(
//         `Target process: ${targetProcess.name}`
//     );

//     log("");

//     /*
//      * ----------------------------------------------------------
//      * Migrate WITs independently
//      * ----------------------------------------------------------
//      */

//     let successCount = 0;
//     let failureCount = 0;

//     for (
//         const configFile
//         of WIT_CONFIGS
//     ) {

//         const success =
//             await migrateWit(
//                 configFile
//             );

//         if (success) {

//             successCount++;

//         } else {

//             failureCount++;
//         }
//     }

//     /*
//      * ----------------------------------------------------------
//      * FINAL REPORT
//      * ----------------------------------------------------------
//      */

//     report.success =
//         failureCount === 0;

//     saveReport();

//     log("");

//     log(
//         "============================================================"
//     );

//     if (
//         failureCount === 0
//     ) {

//         log(
//             "MIGRATION COMPLETED SUCCESSFULLY"
//         );

//         log(
//             `Successful WITs: ${successCount}`
//         );

//         log(
//             `Failed WITs: ${failureCount}`
//         );

//         log(
//             "============================================================"
//         );

//         return;
//     }

//     errorLog(
//         `Migration completed with ${failureCount} WIT failure(s).`
//     );

//     log(
//         `Successful WITs: ${successCount}`
//     );

//     log(
//         `Failed WITs: ${failureCount}`
//     );

//     log(
//         "============================================================"
//     );

//     process.exitCode = 1;
// }


// /* ============================================================
//    START
// ============================================================ */

// main()
//     .catch(error => {

//         errorLog(
//             "FATAL ERROR"
//         );

//         errorLog(
//             formatAxiosError(
//                 error
//             )
//         );

//         report.success =
//             false;

//         try {

//             saveReport();

//         } catch (reportError) {

//             errorLog(
//                 `Could not save report: ${reportError.message}`
//             );
//         }

//         process.exitCode = 1;
//     });

// Be Careful: Email is from an External Source 
// Use caution when opening emails and do not click on links or attachments from unknown senders. For more resources, visit security.cat.com/phishing. 


const fs = require("fs");
const path = require("path");
const axios = require("axios");

const API_VERSION = "7.1";

/* ============================================================
   ENVIRONMENT
============================================================ */

const ORGANIZATION = String(
    process.env.ADO_ORG || ""
).trim();

const PAT = String(
    process.env.ADO_PAT || ""
).trim();

const PROJECT = String(
    process.env.ADO_PROJECT || ""
).trim();

const ADO_URL = (
    String(
        process.env.ADO_URL ||
        `https://dev.azure.com/${ORGANIZATION}`
    ).trim()
).replace(/\/+$/, "");

const SOURCE_PROCESS_ID = String(
    process.env.SOURCE_PROCESS_ID || ""
).trim();

const TARGET_PROCESS_ID = String(
    process.env.TARGET_PROCESS_ID || ""
).trim();

const MIGRATION_MODE = String(
    process.env.MIGRATION_MODE || "dry-run"
).trim().toLowerCase();

const CREATE_MISSING_WITS =
    String(
        process.env.CREATE_MISSING_WITS || "true"
    )
        .trim()
        .toLowerCase() === "true";

const SYNC_LAYOUT =
    String(
        process.env.SYNC_LAYOUT || "true"
    )
        .trim()
        .toLowerCase() === "true";

const CONFIG_DIR = path.join(
    __dirname,
    "..",
    "config"
);

const REPORT_FILE = path.join(
    CONFIG_DIR,
    "migration-report.json"
);

const WIT_CONFIGS = [
    "interview-requirement.json",
    "interview.json"
];


/* ============================================================
   VALIDATION
============================================================ */

function validateEnvironment() {

    const missing = [];

    if (!ORGANIZATION) {
        missing.push("ADO_ORG");
    }

    if (!PAT) {
        missing.push("ADO_PAT");
    }

    if (!PROJECT) {
        missing.push("ADO_PROJECT");
    }

    if (!SOURCE_PROCESS_ID) {
        missing.push("SOURCE_PROCESS_ID");
    }

    if (!TARGET_PROCESS_ID) {
        missing.push("TARGET_PROCESS_ID");
    }

    if (missing.length > 0) {
        throw new Error(
            `Missing environment variables: ${missing.join(", ")}`
        );
    }

    if (
        !["apply", "dry-run"].includes(
            MIGRATION_MODE
        )
    ) {
        throw new Error(
            `Invalid MIGRATION_MODE '${MIGRATION_MODE}'. ` +
            `Use 'apply' or 'dry-run'.`
        );
    }
}


/* ============================================================
   AXIOS
============================================================ */

const api = axios.create({

    baseURL: ADO_URL,

    auth: {
        username: "",
        password: PAT
    },

    headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
    },

    params: {
        "api-version": API_VERSION
    },

    timeout: 120000
});


/* ============================================================
   LOGGING
============================================================ */

function log(message = "") {
    console.log(`[MIGRATE] ${message}`);
}


function errorLog(message = "") {
    console.error(`[ERROR] ${message}`);
}


function formatAxiosError(error) {

    if (!error) {
        return "Unknown error";
    }

    if (error.response) {

        const status =
            error.response.status ||
            "unknown";

        let body;

        try {
            body = JSON.stringify(
                error.response.data,
                null,
                2
            );
        } catch {
            body = String(
                error.response.data
            );
        }

        return `HTTP ${status}\n${body}`;
    }

    if (error.request) {
        return "No response received from Azure DevOps.";
    }

    return (
        error.message ||
        String(error)
    );
}


/* ============================================================
   GENERAL HELPERS
============================================================ */

function encode(value) {
    return encodeURIComponent(value);
}


function clone(value) {

    if (
        value === undefined ||
        value === null
    ) {
        return value;
    }

    return JSON.parse(
        JSON.stringify(value)
    );
}


function removeUndefined(object) {

    return Object.fromEntries(
        Object.entries(object)
            .filter(
                ([, value]) =>
                    value !== undefined
            )
    );
}


function sameName(a, b) {

    return (
        String(a || "")
            .trim()
            .toLowerCase()
        ===
        String(b || "")
            .trim()
            .toLowerCase()
    );
}


function isApply() {
    return MIGRATION_MODE === "apply";
}


/* ============================================================
   FIELD HELPERS
============================================================ */

function isCustomField(field) {

    const referenceName =
        String(
            field?.referenceName || ""
        )
            .toLowerCase();

    const customization =
        String(
            field?.customization || ""
        )
            .toLowerCase();

    return (
        referenceName.startsWith("custom.") ||
        customization === "custom"
    );
}


function isBooleanField(field) {

    const type =
        String(
            field?.type ||
            field?.fieldType ||
            ""
        )
            .trim()
            .toLowerCase();

    return (
        type === "boolean" ||
        type === "bool"
    );
}


function getSafeDefaultValue(field) {

    /*
     * Azure DevOps requires a default value for
     * Boolean fields in certain Process API operations.
     *
     * If DEV already exported a default value,
     * preserve it.
     *
     * Otherwise use false.
     */

    if (
        field?.defaultValue !== undefined &&
        field?.defaultValue !== null
    ) {
        return field.defaultValue;
    }

    if (isBooleanField(field)) {
        return false;
    }

    return undefined;
}


function normalizeAllowedValues(values) {

    if (!Array.isArray(values)) {
        return undefined;
    }

    const result =
        values
            .map(value => {

                if (
                    value !== null &&
                    typeof value === "object"
                ) {
                    return (
                        value.value ??
                        value.name ??
                        value.text ??
                        null
                    );
                }

                return value;
            })
            .filter(
                value =>
                    value !== null &&
                    value !== undefined
            )
            .map(
                value =>
                    String(value)
            );

    return (
        result.length > 0
            ? result
            : undefined
    );
}


/* ============================================================
   WIT CONTROL HELPERS
============================================================ */

function isCustomControl(control) {

    if (!control) {
        return false;
    }

    const id =
        String(
            control.id || ""
        );

    return (
        id.toLowerCase().startsWith("custom.") ||
        control.inherited === false ||
        control.overridden === true
    );
}


/* ============================================================
   PROCESS API
============================================================ */

async function getProcess(processId) {

    const response =
        await api.get(
            `/_apis/work/processes/${encode(processId)}`
        );

    return response.data;
}


/* ============================================================
   WORK ITEM TYPES
============================================================ */

async function getWorkItemTypes(processId) {

    const response =
        await api.get(
            `/_apis/work/processes/${encode(processId)}` +
            `/workItemTypes`
        );

    return (
        response.data?.value ||
        []
    );
}


async function findWit(
    processId,
    witName
) {

    const wits =
        await getWorkItemTypes(
            processId
        );

    return wits.find(
        wit =>
            sameName(
                wit.name,
                witName
            )
    );
}


async function createWit(witConfig) {

    const source =
        witConfig.workItemType;

    const payload = {

        name:
            source.name,

        description:
            source.description || "",

        color:
            source.color || "009CCC",

        icon:
            source.icon || "icon_clipboard",

        isDisabled:
            source.isDisabled === true
    };

    log(
        `Creating target WIT: ${payload.name}`
    );

    const response =
        await api.post(
            `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
            `/workitemtypes`,
            payload
        );

    return response.data;
}


/*
* IMPORTANT:
*
* The target WIT is ALWAYS resolved by NAME.
*
* The returned target.referenceName is then used
* for all subsequent API calls.
*
* We never use:
*
*     config.workItemType.name
*
* as an API reference name.
*/

async function resolveTargetWit(witConfig) {

    const witName =
        witConfig.workItemType.name;

    let targetWit =
        await findWit(
            TARGET_PROCESS_ID,
            witName
        );

    if (targetWit) {

        log(
            `Target WIT '${witName}' -> ` +
            `'${targetWit.referenceName}'`
        );

        return targetWit;
    }

    if (!CREATE_MISSING_WITS) {

        throw new Error(
            `Target WIT '${witName}' does not exist ` +
            `and CREATE_MISSING_WITS=false.`
        );
    }

    targetWit =
        await createWit(
            witConfig
        );

    log(
        `Created target WIT '${witName}' -> ` +
        `'${targetWit.referenceName}'`
    );

    return targetWit;
}


/* ============================================================
   WIT METADATA
============================================================ */

async function updateWitMetadata(
    targetWit,
    witConfig
) {

    const source =
        witConfig.workItemType;

    const payload =
        removeUndefined({

            name:
                source.name,

            description:
                source.description,

            color:
                source.color,

            icon:
                source.icon,

            isDisabled:
                source.isDisabled === true
        });

    if (!isApply()) {

        log(
            `[DRY-RUN] Would update WIT metadata: ${source.name}`
        );

        return;
    }

    await api.patch(
        `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
        `/workItemTypes/${encode(targetWit.referenceName)}`,
        payload
    );

    log(
        `Updated WIT metadata: ${source.name}`
    );
}


/* ============================================================
   FIELDS
============================================================ */

async function getFields(
    processId,
    witReferenceName
) {

    const response =
        await api.get(
            `/_apis/work/processes/${encode(processId)}` +
            `/workItemTypes/${encode(witReferenceName)}/fields`
        );

    return (
        response.data?.value ||
        []
    );
}


function buildFieldPayload(sourceField) {

    const defaultValue =
        getSafeDefaultValue(
            sourceField
        );

    return removeUndefined({

        referenceName:
            sourceField.referenceName,

        required:
            sourceField.required === true,

        readOnly:
            sourceField.readOnly === true,

        allowGroups:
            sourceField.allowGroups === true,

        allowedValues:
            normalizeAllowedValues(
                sourceField.allowedValues
            ),

        defaultValue
    });
}


async function addField(
    targetWit,
    sourceField
) {

    const payload =
        buildFieldPayload(
            sourceField
        );

    if (!isApply()) {

        log(
            `[DRY-RUN] Would add field: ` +
            `${sourceField.referenceName}` +
            (
                isBooleanField(sourceField)
                    ? ` (Boolean default=${payload.defaultValue})`
                    : ""
            )
        );

        return;
    }

    await api.post(
        `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
        `/workItemTypes/${encode(targetWit.referenceName)}/fields`,
        payload
    );

    log(
        `Added field: ${sourceField.referenceName}`
    );
}


async function updateExistingField(
    targetWit,
    sourceField
) {

    const defaultValue =
        getSafeDefaultValue(
            sourceField
        );

    const payload =
        removeUndefined({

            required:
                sourceField.required === true,

            readOnly:
                sourceField.readOnly === true,

            allowGroups:
                sourceField.allowGroups === true,

            allowedValues:
                normalizeAllowedValues(
                    sourceField.allowedValues
                ),

            defaultValue
        });

    if (!isApply()) {

        log(
            `[DRY-RUN] Would update field: ` +
            `${sourceField.referenceName}`
        );

        return;
    }

    await api.patch(
        `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
        `/workItemTypes/${encode(targetWit.referenceName)}` +
        `/fields/${encode(sourceField.referenceName)}`,
        payload
    );

    log(
        `Updated field: ${sourceField.referenceName}`
    );
}


async function migrateFields(
    targetWit,
    sourceFields
) {

    const targetFields =
        await getFields(
            TARGET_PROCESS_ID,
            targetWit.referenceName
        );

    log(
        `Source fields: ${sourceFields.length}`
    );

    log(
        `Target fields: ${targetFields.length}`
    );

    const targetMap =
        new Map();

    for (
        const field
        of targetFields
    ) {

        targetMap.set(
            String(
                field.referenceName
            )
                .trim()
                .toLowerCase(),
            field
        );
    }

    let added = 0;
    let updated = 0;
    let skipped = 0;
    let failed = 0;

    for (
        const sourceField
        of sourceFields
    ) {

        if (
            !isCustomField(
                sourceField
            )
        ) {
            continue;
        }

        const referenceName =
            String(
                sourceField.referenceName || ""
            ).trim();

        if (!referenceName) {

            skipped++;

            continue;
        }

        const targetField =
            targetMap.get(
                referenceName.toLowerCase()
            );

        try {

            if (targetField) {

                await updateExistingField(
                    targetWit,
                    sourceField
                );

                updated++;

            } else {

                await addField(
                    targetWit,
                    sourceField
                );

                added++;
            }

        } catch (error) {

            failed++;

            errorLog(
                `Failed field '${referenceName}'`
            );

            errorLog(
                formatAxiosError(error)
            );
        }
    }

    return {

        source:
            sourceFields.length,

        target:
            targetFields.length,

        added,

        updated,

        skipped,

        failed
    };
}


/* ============================================================
   STATES
============================================================ */

async function getStates(
    processId,
    witReferenceName
) {

    const response =
        await api.get(
            `/_apis/work/processes/${encode(processId)}` +
            `/workItemTypes/${encode(witReferenceName)}/states`
        );

    return (
        response.data?.value ||
        []
    );
}


/*
* Azure DevOps stateCategory is an API concept.
*
* State NAME is completely dynamic.
*
* Example:
*
*     Uat
*     Manager Review
*     ROI
*
* are state names and never belong here.
*
* This function only normalizes the category value
* exported from DEV.
*/

function normalizeStateCategory(category) {

    const value =
        String(category || "")
            .trim()
            .replace(/\s+/g, "")
            .replace(/-/g, "")
            .toLowerCase();

    if (!value) {

        throw new Error(
            "State category is missing."
        );
    }

    /*
     * Normalize the standard Azure DevOps category
     * names without maintaining business state names.
     */

    const normalized = {

        proposed:
            "Proposed",

        inprogress:
            "InProgress",

        resolved:
            "Resolved",

        completed:
            "Completed",

        complete:
            "Completed",

        removed:
            "Removed"
    };

    /*
     * If Azure DevOps gives us one of the currently
     * known category names, return the canonical value.
     *
     * Otherwise preserve the exported category instead
     * of silently converting it to "Proposed".
     *
     * This prevents accidental corruption of future
     * configuration.
     */

    return (
        normalized[value] ||
        String(category).trim()
    );
}


const STATE_CATEGORY_ORDER = {

    Proposed: 1,

    InProgress: 2,

    Resolved: 3,

    Completed: 4,

    Removed: 5
};


function getCategoryRank(state) {

    const category =
        normalizeStateCategory(
            state.stateCategory
        );

    return (
        STATE_CATEGORY_ORDER[
            category
        ] || 99
    );
}


function calculateValidStateOrder(
    targetStates,
    desiredState
) {

    const category =
        normalizeStateCategory(
            desiredState.stateCategory
        );

    const categoryStates =
        targetStates
            .filter(
                state =>
                    sameName(
                        normalizeStateCategory(
                            state.stateCategory
                        ),
                        category
                    )
            )
            .sort(
                (a, b) =>
                    Number(a.order || 0) -
                    Number(b.order || 0)
            );

    if (
        categoryStates.length === 0
    ) {

        /*
         * Use the normal category starting point
         * when the target currently has no state
         * in this category.
         */

        return (
            STATE_CATEGORY_ORDER[
                category
            ] || 1
        );
    }

    const maxOrder =
        Math.max(
            ...categoryStates.map(
                state =>
                    Number(
                        state.order || 0
                    )
            )
        );

    return maxOrder + 1;
}


async function updateExistingState(
    targetWit,
    sourceState,
    targetState
) {

    /*
     * IMPORTANT:
     *
     * Azure DevOps state UPDATE API accepts:
     *
     *     name
     *     color
     *     order
     *
     * We intentionally do NOT send stateCategory.
     */

    const payload = {

        name:
            sourceState.name,

        color:
            sourceState.color ||
            targetState.color ||
            "B2B2B2"
    };

    if (!isApply()) {

        log(
            `[DRY-RUN] Would update existing state: ` +
            `${sourceState.name}`
        );

        return;
    }

    await api.patch(
        `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
        `/workItemTypes/${encode(targetWit.referenceName)}` +
        `/states/${encode(targetState.id)}`,
        payload
    );

    log(
        `Updated state: ${sourceState.name}`
    );
}


async function createMissingState(
    targetWit,
    sourceState,
    targetStates
) {

    const category =
        normalizeStateCategory(
            sourceState.stateCategory
        );

    const order =
        calculateValidStateOrder(
            targetStates,
            sourceState
        );

    const payload = {

        name:
            sourceState.name,

        color:
            sourceState.color ||
            "B2B2B2",

        stateCategory:
            category,

        order
    };

    if (!isApply()) {

        log(
            `[DRY-RUN] Would create state: ` +
            `${sourceState.name} ` +
            `(category=${category}, order=${order})`
        );

        return;
    }

    try {

        await api.post(
            `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
            `/workItemTypes/${encode(targetWit.referenceName)}` +
            `/states`,
            payload
        );

        log(
            `Created state: ${sourceState.name} ` +
            `(category=${category}, order=${order})`
        );

    } catch (error) {

        /*
         * Azure DevOps may reject an explicit order
         * depending on the current target workflow.
         *
         * Retry without order.
         */

        if (
            error.response &&
            error.response.status === 400
        ) {

            log(
                `Retrying state '${sourceState.name}' ` +
                `without explicit order.`
            );

            const retryPayload = {

                name:
                    sourceState.name,

                color:
                    sourceState.color ||
                    "B2B2B2",

                stateCategory:
                    category
            };

            await api.post(
                `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
                `/workItemTypes/${encode(targetWit.referenceName)}` +
                `/states`,
                retryPayload
            );

            log(
                `Created state on retry: ${sourceState.name}`
            );

            return;
        }

        throw error;
    }
}


async function migrateStates(
    targetWit,
    sourceStates
) {

    let targetStates =
        await getStates(
            TARGET_PROCESS_ID,
            targetWit.referenceName
        );

    log(
        `Source states: ${sourceStates.length}`
    );

    log(
        `Target states: ${targetStates.length}`
    );

    let updated = 0;
    let created = 0;
    let skipped = 0;
    let failed = 0;

    /*
     * Sort only for creation order.
     *
     * State names themselves are NEVER hardcoded.
     */

    const orderedSourceStates =
        [...sourceStates]
            .sort(
                (a, b) => {

                    const categoryA =
                        getCategoryRank(a);

                    const categoryB =
                        getCategoryRank(b);

                    if (
                        categoryA !== categoryB
                    ) {
                        return (
                            categoryA -
                            categoryB
                        );
                    }

                    return (
                        Number(a.order || 0) -
                        Number(b.order || 0)
                    );
                }
            );

    for (
        const sourceState
        of orderedSourceStates
    ) {

        const stateName =
            String(
                sourceState.name || ""
            ).trim();

        if (!stateName) {

            skipped++;

            errorLog(
                "Skipping state because its name is empty."
            );

            continue;
        }

        try {

            const targetState =
                targetStates.find(
                    state =>
                        sameName(
                            state.name,
                            stateName
                        )
                );

            if (targetState) {

                await updateExistingState(
                    targetWit,
                    sourceState,
                    targetState
                );

                updated++;

            } else {

                await createMissingState(
                    targetWit,
                    sourceState,
                    targetStates
                );

                created++;

                /*
                 * Refresh target state list so that
                 * the next new state gets a valid order.
                 */

                targetStates =
                    await getStates(
                        TARGET_PROCESS_ID,
                        targetWit.referenceName
                    );
            }

        } catch (error) {

            failed++;

            errorLog(
                `Failed state '${stateName}'`
            );

            errorLog(
                formatAxiosError(error)
            );
        }
    }

    return {

        source:
            sourceStates.length,

        target:
            targetStates.length,

        updated,

        created,

        skipped,

        failed
    };
}


/* ============================================================
   RULES
============================================================ */

async function getRules(
    processId,
    witReferenceName
) {

    const response =
        await api.get(
            `/_apis/work/processes/${encode(processId)}` +
            `/workItemTypes/${encode(witReferenceName)}/rules`
        );

    return (
        response.data?.value ||
        []
    );
}


/*
* Replace source WIT references inside rule definitions.
*
* This is important because rules can contain references
* such as the source WIT name/reference.
*/

function replaceWitReferences(
    value,
    sourceWitReferenceName,
    targetWitReferenceName
) {

    if (
        value === null ||
        value === undefined
    ) {
        return value;
    }

    if (
        typeof value === "string"
    ) {

        if (
            sourceWitReferenceName &&
            value === sourceWitReferenceName
        ) {
            return targetWitReferenceName;
        }

        /*
         * Also replace the source reference when it appears
         * inside a larger string.
         */

        if (
            sourceWitReferenceName &&
            value.includes(
                sourceWitReferenceName
            )
        ) {

            return value.replaceAll(
                sourceWitReferenceName,
                targetWitReferenceName
            );
        }

        return value;
    }

    if (Array.isArray(value)) {

        return value.map(
            item =>
                replaceWitReferences(
                    item,
                    sourceWitReferenceName,
                    targetWitReferenceName
                )
        );
    }

    if (
        typeof value === "object"
    ) {

        const result = {};

        for (
            const [key, childValue]
            of Object.entries(value)
        ) {

            result[key] =
                replaceWitReferences(
                    childValue,
                    sourceWitReferenceName,
                    targetWitReferenceName
                );
        }

        return result;
    }

    return value;
}


function normalizeRule(
    rule,
    sourceWitReferenceName,
    targetWitReferenceName
) {

    const result =
        clone(rule);

    delete result.id;
    delete result.url;
    delete result._links;

    return replaceWitReferences(
        result,
        sourceWitReferenceName,
        targetWitReferenceName
    );
}


async function migrateRules(
    targetWit,
    sourceWitReferenceName,
    sourceRules
) {

    const targetRules =
        await getRules(
            TARGET_PROCESS_ID,
            targetWit.referenceName
        );

    log(
        `Source rules: ${sourceRules.length}`
    );

    log(
        `Target rules: ${targetRules.length}`
    );

    let created = 0;
    let skipped = 0;
    let failed = 0;

    for (
        const sourceRule
        of sourceRules
    ) {

        const ruleName =
            String(
                sourceRule.name || ""
            ).trim();

        try {

            const existingRule =
                targetRules.find(
                    rule =>
                        sameName(
                            rule.name,
                            ruleName
                        )
                );

            if (existingRule) {

                log(
                    `Rule already exists: ${ruleName}`
                );

                skipped++;

                continue;
            }

            const payload =
                normalizeRule(
                    sourceRule,
                    sourceWitReferenceName,
                    targetWit.referenceName
                );

            if (!isApply()) {

                log(
                    `[DRY-RUN] Would create rule: ${ruleName}`
                );

                created++;

                continue;
            }

            await api.post(
                `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
                `/workItemTypes/${encode(targetWit.referenceName)}/rules`,
                payload
            );

            log(
                `Created rule: ${ruleName}`
            );

            created++;

        } catch (error) {

            /*
             * 304 is not a migration failure.
             */

            if (
                error.response &&
                error.response.status === 304
            ) {

                log(
                    `Rule not modified: ${ruleName}`
                );

                skipped++;

                continue;
            }

            failed++;

            errorLog(
                `Failed rule '${ruleName}'`
            );

            errorLog(
                formatAxiosError(error)
            );
        }
    }

    return {

        source:
            sourceRules.length,

        target:
            targetRules.length,

        created,

        skipped,

        failed
    };
}


/* ============================================================
   LAYOUT
============================================================ */

async function getLayout(
    processId,
    witReferenceName
) {

    const response =
        await api.get(
            `/_apis/work/processes/${encode(processId)}` +
            `/workItemTypes/${encode(witReferenceName)}/layout`
        );

    return response.data;
}


/*
* Standard inherited pages:
*
*     History
*     Links
*     Attachments
*
* should remain controlled by the target process.
*/

function isStandardPage(page) {

    const pageType =
        String(
            page?.pageType || ""
        )
            .trim()
            .toLowerCase();

    return (
        pageType === "history" ||
        pageType === "links" ||
        pageType === "attachments"
    );
}


function hasMigratableControls(section) {

    return (
        section?.groups || []
    ).some(
        group =>
            hasMigratableGroup(group)
    );
}


function hasMigratableGroup(group) {

    if (!group) {
        return false;
    }

    if (
        group.inherited === false ||
        group.overridden === true
    ) {
        return true;
    }

    return (
        group.controls || []
    ).some(
        control =>
            isCustomControl(control)
    );
}


function isMigratablePage(page) {

    if (!page) {
        return false;
    }

    if (isStandardPage(page)) {
        return false;
    }

    if (
        page.pageType === "custom" ||
        page.inherited === false ||
        page.overridden === true
    ) {
        return true;
    }

    return (
        page.sections || []
    ).some(
        section =>
            hasMigratableControls(section)
    );
}


function findPage(
    layout,
    sourcePage
) {

    const pages =
        layout?.pages || [];

    if (sourcePage.id) {

        const byId =
            pages.find(
                page =>
                    page.id ===
                    sourcePage.id
            );

        if (byId) {
            return byId;
        }
    }

    return pages.find(
        page =>
            sameName(
                page.label,
                sourcePage.label
            )
    );
}


function findGroup(
    section,
    sourceGroup
) {

    const groups =
        section?.groups || [];

    if (sourceGroup.id) {

        const byId =
            groups.find(
                group =>
                    group.id ===
                    sourceGroup.id
            );

        if (byId) {
            return byId;
        }
    }

    return groups.find(
        group =>
            sameName(
                group.label,
                sourceGroup.label
            )
    );
}


function findControl(
    group,
    sourceControl
) {

    const controls =
        group?.controls || [];

    if (sourceControl.id) {

        const byId =
            controls.find(
                control =>
                    sameName(
                        control.id,
                        sourceControl.id
                    )
            );

        if (byId) {
            return byId;
        }
    }

    return controls.find(
        control =>
            sameName(
                control.label,
                sourceControl.label
            )
    );
}


/* ============================================================
   PAGE PAYLOAD
============================================================ */

function buildPagePayload(
    sourcePage,
    targetPage
) {

    /*
     * For an existing page, sections MUST NOT be sent.
     *
     * For a new page, sections can be included.
     * Azure DevOps 7.1 explicitly supports sections
     * in the page-create payload.
     */

    return removeUndefined({

        id:
            targetPage?.id ||
            undefined,

        label:
            sourcePage.label,

        order:
            sourcePage.order,

        pageType:
            sourcePage.pageType ||
            "custom",

        visible:
            sourcePage.visible !== false,

        locked:
            sourcePage.locked === true,

        isContribution:
            sourcePage.isContribution === true,

        contribution:
            sourcePage.contribution,

        sections:
            targetPage
                ? undefined
                : (
                    sourcePage.sections || []
                ).map(
                    section => ({
                        id:
                            section.id,

                        groups: [],

                        overridden:
                            false
                    })
                )
    });
}


/* ============================================================
   GROUP PAYLOAD
============================================================ */

function buildGroupPayload(
    sourceGroup,
    targetGroup
) {

    return removeUndefined({

        id:
            targetGroup?.id ||
            undefined,

        label:
            sourceGroup.label,

        order:
            sourceGroup.order,

        visible:
            sourceGroup.visible !== false,

        height:
            sourceGroup.height,

        isContribution:
            sourceGroup.isContribution === true,

        contribution:
            sourceGroup.contribution
    });
}


/* ============================================================
   CONTROL PAYLOAD
============================================================ */

function buildControlPayload(
    sourceControl,
    targetControl
) {

    return removeUndefined({

        id:
            targetControl?.id ||
            (
                isCustomControl(sourceControl)
                    ? sourceControl.id
                    : undefined
            ),

        label:
            sourceControl.label,

        order:
            sourceControl.order,

        controlType:
            sourceControl.controlType,

        visible:
            sourceControl.visible !== false,

        readOnly:
            sourceControl.readOnly === true,

        watermark:
            sourceControl.watermark,

        metadata:
            sourceControl.metadata,

        height:
            sourceControl.height,

        isContribution:
            sourceControl.isContribution === true,

        contribution:
            sourceControl.contribution
    });
}


/* ============================================================
   PAGE MIGRATION
============================================================ */

async function addOrUpdatePage(
    targetWit,
    sourcePage,
    targetLayout
) {

    const targetPage =
        findPage(
            targetLayout,
            sourcePage
        );

    const payload =
        buildPagePayload(
            sourcePage,
            targetPage
        );

    if (!targetPage) {

        if (!isApply()) {

            log(
                `[DRY-RUN] Would create page: ` +
                `${sourcePage.label}`
            );

            return null;
        }

        const response =
            await api.post(
                `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
                `/workItemTypes/${encode(targetWit.referenceName)}` +
                `/layout/pages`,
                payload
            );

        log(
            `Created page: ${sourcePage.label}`
        );

        return response.data;
    }

    if (!isApply()) {

        log(
            `[DRY-RUN] Would update page: ` +
            `${sourcePage.label}`
        );

        return targetPage;
    }

    const response =
        await api.patch(
            `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
            `/workItemTypes/${encode(targetWit.referenceName)}` +
            `/layout/pages`,
            payload
        );

    log(
        `Updated page: ${sourcePage.label}`
    );

    return response.data;
}


/* ============================================================
   GROUP MIGRATION
============================================================ */

async function addOrUpdateGroup(
    targetWit,
    sourceGroup,
    targetPage,
    targetSection
) {

    const targetGroup =
        findGroup(
            targetSection,
            sourceGroup
        );

    const payload =
        buildGroupPayload(
            sourceGroup,
            targetGroup
        );

    if (!targetGroup) {

        if (!isApply()) {

            log(
                `[DRY-RUN] Would create group: ` +
                `${sourceGroup.label}`
            );

            return null;
        }

        const response =
            await api.post(
                `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
                `/workItemTypes/${encode(targetWit.referenceName)}` +
                `/layout/pages/${encode(targetPage.id)}` +
                `/sections/${encode(targetSection.id)}` +
                `/groups`,
                payload
            );

        log(
            `Created group: ${sourceGroup.label}`
        );

        return response.data;
    }

    if (!isApply()) {

        log(
            `[DRY-RUN] Would update group: ` +
            `${sourceGroup.label}`
        );

        return targetGroup;
    }

    const response =
        await api.patch(
            `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
            `/workItemTypes/${encode(targetWit.referenceName)}` +
            `/layout/pages/${encode(targetPage.id)}` +
            `/sections/${encode(targetSection.id)}` +
            `/groups/${encode(targetGroup.id)}`,
            payload
        );

    log(
        `Updated group: ${sourceGroup.label}`
    );

    return response.data;
}


/* ============================================================
   CONTROL MIGRATION
============================================================ */

async function addOrUpdateControl(
    targetWit,
    sourceControl,
    targetGroup
) {

    const targetControl =
        findControl(
            targetGroup,
            sourceControl
        );

    const payload =
        buildControlPayload(
            sourceControl,
            targetControl
        );

    if (!targetControl) {

        if (!isApply()) {

            log(
                `[DRY-RUN] Would create control: ` +
                `${sourceControl.label}`
            );

            return;
        }

        await api.post(
            `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
            `/workItemTypes/${encode(targetWit.referenceName)}` +
            `/layout/groups/${encode(targetGroup.id)}/controls`,
            payload
        );

        log(
            `Created control: ${sourceControl.label}`
        );

        return;
    }

    if (!isApply()) {

        log(
            `[DRY-RUN] Would update control: ` +
            `${sourceControl.label}`
        );

        return;
    }

    await api.patch(
        `/_apis/work/processes/${encode(TARGET_PROCESS_ID)}` +
        `/workItemTypes/${encode(targetWit.referenceName)}` +
        `/layout/groups/${encode(targetGroup.id)}` +
        `/controls/${encode(targetControl.id)}`,
        payload
    );

    log(
        `Updated control: ${sourceControl.label}`
    );
}


/* ============================================================
   LAYOUT MIGRATION
============================================================ */

async function migrateLayout(
    targetWit,
    sourceLayout
) {

    if (!SYNC_LAYOUT) {

        log(
            "Layout synchronization disabled."
        );

        return {
            skipped: true
        };
    }

    if (!sourceLayout) {

        log(
            "No source layout found."
        );

        return {
            skipped: true
        };
    }

    log(
        "Starting layout synchronization..."
    );

    let targetLayout =
        await getLayout(
            TARGET_PROCESS_ID,
            targetWit.referenceName
        );

    const sourcePages =
        sourceLayout.pages || [];

    let pagesProcessed = 0;
    let groupsProcessed = 0;
    let controlsProcessed = 0;
    let failed = 0;

    for (
        const sourcePage
        of sourcePages
    ) {

        /*
         * Never copy standard pages such as:
         *
         * History
         * Links
         * Attachments
         */

        if (
            !isMigratablePage(
                sourcePage
            )
        ) {

            log(
                `Skipping inherited/standard page: ` +
                `${sourcePage.label}`
            );

            continue;
        }

        try {

            /*
             * ====================================================
             * PAGE
             * ====================================================
             */

            await addOrUpdatePage(
                targetWit,
                sourcePage,
                targetLayout
            );

            pagesProcessed++;

            if (!isApply()) {

                /*
                 * In dry-run we don't have newly created
                 * target IDs. Continue reporting what would
                 * happen without attempting child API calls.
                 */

                continue;
            }

            targetLayout =
                await getLayout(
                    TARGET_PROCESS_ID,
                    targetWit.referenceName
                );

            const targetPage =
                findPage(
                    targetLayout,
                    sourcePage
                );

            if (!targetPage) {

                failed++;

                errorLog(
                    `Could not resolve target page after operation: ` +
                    `${sourcePage.label}`
                );

                continue;
            }

            /*
             * ====================================================
             * SECTIONS
             * ====================================================
             *
             * Sections cannot be independently created using
             * the same child API pattern as groups.
             *
             * New sections are therefore supplied during
             * page creation.
             *
             * For an existing page, we map source sections
             * to target sections by ID, then by position.
             */

            const sourceSections =
                sourcePage.sections || [];

            const targetSections =
                targetPage.sections || [];

            for (
                let sectionIndex = 0;
                sectionIndex < sourceSections.length;
                sectionIndex++
            ) {

                const sourceSection =
                    sourceSections[sectionIndex];

                let targetSection = null;

                if (
                    sourceSection.id
                ) {

                    targetSection =
                        targetSections.find(
                            section =>
                                sameName(
                                    section.id,
                                    sourceSection.id
                                )
                        );
                }

                if (!targetSection) {

                    targetSection =
                        targetSections[
                            sectionIndex
                        ];
                }

                if (!targetSection) {

                    errorLog(
                        `Could not resolve section ${sectionIndex} ` +
                        `for page '${sourcePage.label}'`
                    );

                    failed++;

                    continue;
                }

                /*
                 * =================================================
                 * GROUPS
                 * =================================================
                 */

                for (
                    const sourceGroup
                    of sourceSection.groups || []
                ) {

                    if (
                        !hasMigratableGroup(
                            sourceGroup
                        )
                    ) {

                        continue;
                    }

                    try {

                        await addOrUpdateGroup(
                            targetWit,
                            sourceGroup,
                            targetPage,
                            targetSection
                        );

                        groupsProcessed++;

                        /*
                         * Refresh after every group so the
                         * returned target group ID is current.
                         */

                        targetLayout =
                            await getLayout(
                                TARGET_PROCESS_ID,
                                targetWit.referenceName
                            );

                        const refreshedPage =
                            findPage(
                                targetLayout,
                                sourcePage
                            );

                        if (!refreshedPage) {

                            failed++;

                            errorLog(
                                `Could not resolve refreshed page: ` +
                                `${sourcePage.label}`
                            );

                            continue;
                        }

                        const refreshedSections =
                            refreshedPage.sections || [];

                        let refreshedSection =
                            null;

                        if (
                            sourceSection.id
                        ) {

                            refreshedSection =
                                refreshedSections.find(
                                    section =>
                                        sameName(
                                            section.id,
                                            sourceSection.id
                                        )
                                );
                        }

                        if (!refreshedSection) {

                            refreshedSection =
                                refreshedSections[
                                    sectionIndex
                                ];
                        }

                        if (!refreshedSection) {

                            failed++;

                            errorLog(
                                `Could not resolve refreshed section ` +
                                `for page '${sourcePage.label}'`
                            );

                            continue;
                        }

                        const refreshedGroup =
                            findGroup(
                                refreshedSection,
                                sourceGroup
                            );

                        if (!refreshedGroup) {

                            failed++;

                            errorLog(
                                `Could not resolve target group: ` +
                                `${sourceGroup.label}`
                            );

                            continue;
                        }

                        /*
                         * =============================================
                         * CONTROLS
                         * =============================================
                         */

                        for (
                            const sourceControl
                            of sourceGroup.controls || []
                        ) {

                            /*
                             * Standard inherited controls stay under
                             * the target process.
                             *
                             * Only custom/overridden controls are
                             * synchronized.
                             */

                            if (
                                !isCustomControl(
                                    sourceControl
                                )
                            ) {
                                continue;
                            }

                            try {

                                await addOrUpdateControl(
                                    targetWit,
                                    sourceControl,
                                    refreshedGroup
                                );

                                controlsProcessed++;

                            } catch (error) {

                                failed++;

                                errorLog(
                                    `Failed control '${sourceControl.label}'`
                                );

                                errorLog(
                                    formatAxiosError(error)
                                );
                            }
                        }

                    } catch (error) {

                        failed++;

                        errorLog(
                            `Failed group '${sourceGroup.label}'`
                        );

                        errorLog(
                            formatAxiosError(error)
                        );
                    }
                }
            }

        } catch (error) {

            failed++;

            errorLog(
                `Failed page '${sourcePage.label}'`
            );

            errorLog(
                formatAxiosError(error)
            );
        }
    }

    log(
        `Layout synchronization completed. ` +
        `Pages=${pagesProcessed}, ` +
        `Groups=${groupsProcessed}, ` +
        `Controls=${controlsProcessed}, ` +
        `Failures=${failed}`
    );

    return {

        skipped: false,

        pagesProcessed,

        groupsProcessed,

        controlsProcessed,

        failed
    };
}


/* ============================================================
   CONFIGURATION
============================================================ */

function loadConfig(fileName) {

    const filePath =
        path.join(
            CONFIG_DIR,
            fileName
        );

    if (
        !fs.existsSync(filePath)
    ) {

        throw new Error(
            `Configuration file not found: ${filePath}`
        );
    }

    return JSON.parse(
        fs.readFileSync(
            filePath,
            "utf8"
        )
    );
}


/* ============================================================
   REPORT
============================================================ */

const report = {

    startedAt:
        new Date().toISOString(),

    organization:
        ORGANIZATION,

    project:
        PROJECT,

    sourceProcessId:
        SOURCE_PROCESS_ID,

    targetProcessId:
        TARGET_PROCESS_ID,

    migrationMode:
        MIGRATION_MODE,

    createMissingWits:
        CREATE_MISSING_WITS,

    syncLayout:
        SYNC_LAYOUT,

    workItemTypes: [],

    success: false,

    completedAt: null
};


function saveReport() {

    report.completedAt =
        new Date().toISOString();

    fs.mkdirSync(
        CONFIG_DIR,
        {
            recursive: true
        }
    );

    fs.writeFileSync(
        REPORT_FILE,
        JSON.stringify(
            report,
            null,
            2
        )
    );

    log(
        `Migration report: ${REPORT_FILE}`
    );
}


/* ============================================================
   MIGRATE ONE WIT
============================================================ */

async function migrateWit(
    configFile
) {

    const config =
        loadConfig(
            configFile
        );

    const witName =
        config.workItemType.name;

    const witReport = {

        file:
            configFile,

        name:
            witName,

        sourceReferenceName:
            config.workItemType.referenceName ||
            null,

        targetReferenceName:
            null,

        success:
            false,

        fields:
            null,

        states:
            null,

        rules:
            null,

        layout:
            null,

        errors:
            []
    };

    report.workItemTypes.push(
        witReport
    );

    log("");

    log(
        "============================================================"
    );

    log(
        `Migrating WIT: ${witName}`
    );

    log(
        "============================================================"
    );

    try {

        /*
         * ========================================================
         * SOURCE CONFIG VALIDATION
         * ========================================================
         */

        if (
            config.source &&
            config.source.processId &&
            String(
                config.source.processId
            ) !== SOURCE_PROCESS_ID
        ) {

            throw new Error(
                `Source process mismatch for ${witName}. ` +
                `Config=${config.source.processId}, ` +
                `Pipeline=${SOURCE_PROCESS_ID}`
            );
        }

        /*
         * ========================================================
         * RESOLVE TARGET WIT
         * ========================================================
         */

        const targetWit =
            await resolveTargetWit(
                config
            );

        const targetWitRefName =
            targetWit.referenceName;

        const sourceWitRefName =
            String(
                config.workItemType.referenceName ||
                ""
            ).trim();

        witReport.targetReferenceName =
            targetWitRefName;

        log(
            `Source WIT reference : ` +
            `${sourceWitRefName || "(not supplied)"}`
        );

        log(
            `Target WIT reference : ` +
            `${targetWitRefName}`
        );

        /*
         * ========================================================
         * METADATA
         * ========================================================
         */

        await updateWitMetadata(
            targetWit,
            config
        );

        /*
         * ========================================================
         * FIELDS
         * ========================================================
         */

        witReport.fields =
            await migrateFields(
                targetWit,
                config.customFields || []
            );

        /*
         * ========================================================
         * STATES
         * ========================================================
         */

        witReport.states =
            await migrateStates(
                targetWit,
                config.states || []
            );

        /*
         * ========================================================
         * RULES
         * ========================================================
         *
         * IMPORTANT:
         *
         * Rules use targetWit.referenceName.
         *
         * Any source WIT reference contained inside
         * the exported rule definition is replaced
         * with targetWit.referenceName.
         */

        witReport.rules =
            await migrateRules(
                targetWit,
                sourceWitRefName,
                config.rules || []
            );

        /*
         * ========================================================
         * LAYOUT
         * ========================================================
         */

        witReport.layout =
            await migrateLayout(
                targetWit,
                config.layout
            );

        /*
         * ========================================================
         * SUCCESS
         * ========================================================
         */

        witReport.success =
            true;

        log(
            `Completed WIT: ${witName}`
        );

        return true;

    } catch (error) {

        witReport.success =
            false;

        const message =
            formatAxiosError(error);

        witReport.errors.push(
            message
        );

        errorLog(
            `Migration failed for ${configFile}`
        );

        errorLog(
            message
        );

        return false;
    }
}


/* ============================================================
   MAIN
============================================================ */

async function main() {

    validateEnvironment();

    log("");

    log(
        "============================================================"
    );

    log(
        "AZURE DEVOPS PROCESS MIGRATION"
    );

    log(
        "============================================================"
    );

    log(
        `Organization : ${ORGANIZATION}`
    );

    log(
        `Project      : ${PROJECT}`
    );

    log(
        `Source PID   : ${SOURCE_PROCESS_ID}`
    );

    log(
        `Target PID   : ${TARGET_PROCESS_ID}`
    );

    log(
        `Mode         : ${MIGRATION_MODE.toUpperCase()}`
    );

    log(
        `Create WITs  : ${CREATE_MISSING_WITS}`
    );

    log(
        `Sync Layout  : ${SYNC_LAYOUT}`
    );

    log("");

    /*
     * ============================================================
     * VALIDATE PROCESSES
     * ============================================================
     */

    const sourceProcess =
        await getProcess(
            SOURCE_PROCESS_ID
        );

    const targetProcess =
        await getProcess(
            TARGET_PROCESS_ID
        );

    log(
        `Source process: ${sourceProcess.name}`
    );

    log(
        `Target process: ${targetProcess.name}`
    );

    log("");

    /*
     * ============================================================
     * MIGRATE WITS
     * ============================================================
     */

    let successCount = 0;
    let failureCount = 0;

    for (
        const configFile
        of WIT_CONFIGS
    ) {

        const success =
            await migrateWit(
                configFile
            );

        if (success) {

            successCount++;

        } else {

            failureCount++;
        }
    }

    /*
     * ============================================================
     * REPORT
     * ============================================================
     */

    report.success =
        failureCount === 0;

    saveReport();

    log("");

    log(
        "============================================================"
    );

    if (
        failureCount === 0
    ) {

        log(
            "MIGRATION COMPLETED SUCCESSFULLY"
        );

        log(
            `Successful WITs: ${successCount}`
        );

        log(
            `Failed WITs: ${failureCount}`
        );

        log(
            "============================================================"
        );

        return;
    }

    errorLog(
        `Migration completed with ${failureCount} WIT failure(s).`
    );

    log(
        `Successful WITs: ${successCount}`
    );

    log(
        `Failed WITs: ${failureCount}`
    );

    log(
        "============================================================"
    );

    process.exitCode = 1;
}


/* ============================================================
   START
============================================================ */

main()
    .catch(error => {

        errorLog(
            "FATAL ERROR"
        );

        errorLog(
            formatAxiosError(error)
        );

        report.success =
            false;

        try {

            saveReport();

        } catch (reportError) {

            errorLog(
                `Could not save report: ` +
                `${reportError.message}`
            );
        }

        process.exitCode = 1;
    });

 
 


