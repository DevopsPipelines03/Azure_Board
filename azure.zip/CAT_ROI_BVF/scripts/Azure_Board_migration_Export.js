
"use strict";
 
const axios = require("axios");
const fs = require("fs");
const path = require("path");
 
/*
 * ------------------------------------------------------------
 * CONFIGURATION
 * ------------------------------------------------------------
 */
 
const API_VERSION = "7.1";
 
const ORGANIZATION =
    process.env.ADO_ORG;
 
const PAT =
    process.env.ADO_PAT;
 
const PROJECT =
    process.env.ADO_PROJECT;
 
const ADO_URL =
    process.env.ADO_URL ||
    `https://dev.azure.com/${ORGANIZATION}`;
 
const SOURCE_PROCESS_ID =
    process.env.SOURCE_PROCESS_ID;
 
/*
 * WIT scope.
 *
 * These are the two WITs that are in your migration POC.
 *
 * IMPORTANT:
 * We are NOT hardcoding their fields.
 *
 * Fields are discovered dynamically from Azure DevOps.
 */
const WITS = (
    process.env.WIT_NAMES ||
    "Role Task Interview,ROI BVF Scoring Interview"
)
    .split(",")
    .map(x => x.trim())
    .filter(Boolean);
 
const OUTPUT_DIR =
    path.join(
        __dirname,
        "..",
        "config"
    );
 
/*
 * ------------------------------------------------------------
 * VALIDATION
 * ------------------------------------------------------------
 */
 
function validateEnvironment() {
 
    const required = {
        ADO_ORG: ORGANIZATION,
        ADO_PAT: PAT,
        ADO_PROJECT: PROJECT,
        ADO_URL,
        SOURCE_PROCESS_ID
    };
 
    const missing =
        Object.entries(required)
            .filter(
                ([, value]) =>
                    !value ||
                    String(value).trim() === ""
            )
            .map(([name]) => name);
 
    if (missing.length > 0) {
 
        throw new Error(
            `Missing required environment variables: ${missing.join(", ")}`
        );
    }
 
    if (!Array.isArray(WITS) || WITS.length === 0) {
 
        throw new Error(
            "No WIT names were supplied."
        );
    }
}
 
/*
 * ------------------------------------------------------------
 * AZURE DEVOPS CLIENT
 * ------------------------------------------------------------
 */
 
const api = axios.create({
 
    baseURL:
        ADO_URL.replace(/\/$/, ""),
 
    auth: {
        username: "",
        password: PAT
    },
 
    headers: {
        "Content-Type": "application/json",
        "Accept": "application/json"
    },
 
    params: {
        "api-version": API_VERSION
    },
 
    timeout: 60000
});
 
/*
 * ------------------------------------------------------------
 * LOGGING
 * ------------------------------------------------------------
 */
 
function log(message = "") {
    console.log(`[EXPORT] ${message}`);
}
 
/*
 * ------------------------------------------------------------
 * ERROR HANDLING
 * ------------------------------------------------------------
 */
 
function printApiError(error) {
 
    if (error.response) {
 
        console.error(
            `HTTP ${error.response.status} ${error.response.statusText || ""}`
        );
 
        if (error.response.data) {
 
            console.error(
                JSON.stringify(
                    error.response.data,
                    null,
                    2
                )
            );
        }
 
        return;
    }
 
    console.error(
        error.message
    );
}
 
/*
 * ------------------------------------------------------------
 * OUTPUT DIRECTORY
 * ------------------------------------------------------------
 */
 
function ensureOutputDirectory() {
 
    if (!fs.existsSync(OUTPUT_DIR)) {
 
        fs.mkdirSync(
            OUTPUT_DIR,
            {
                recursive: true
            }
        );
    }
}
 
/*
 * ------------------------------------------------------------
 * SAFE FILE NAME
 * ------------------------------------------------------------
 */
 
function safeFileName(name) {
 
    return name
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-|-$/g, "");
}
 
/*
 * ------------------------------------------------------------
 * GET ALL WITS FROM SOURCE PROCESS
 * ------------------------------------------------------------
 *
 * Azure DevOps:
 *
 * GET
 * /_apis/work/processes/{processId}/workItemTypes
 *
 * ------------------------------------------------------------
 */
 
async function getProcessWorkItemTypes() {
 
    const url =
        `/_apis/work/processes/` +
        `${encodeURIComponent(SOURCE_PROCESS_ID)}` +
        `/workItemTypes`;
 
    const response =
        await api.get(url);
 
    return response.data.value || [];
}
 
/*
 * ------------------------------------------------------------
 * RESOLVE WIT
 * ------------------------------------------------------------
 *
 * We resolve:
 *
 * Interview Requirement
 *       ->
 * Sandbox.InterviewRequirement
 *
 * Interview
 *       ->
 * Sandbox.Interview
 *
 * without hardcoding reference names.
 * ------------------------------------------------------------
 */
 
async function resolveWit(witName) {
 
    const wits =
        await getProcessWorkItemTypes();
 
    const wit =
        wits.find(
            item =>
                item.name &&
                item.name.toLowerCase() ===
                witName.toLowerCase()
        );
 
    if (!wit) {
 
        throw new Error(
            `WIT '${witName}' was not found in source process ${SOURCE_PROCESS_ID}.`
        );
    }
 
    log(
        `Resolved '${witName}' -> '${wit.referenceName}'`
    );
 
    return wit;
}
 
/*
 * ------------------------------------------------------------
 * GET WIT DETAILS
 * ------------------------------------------------------------
 */
 
async function getWitDetails(
    referenceName
) {
 
    const url =
        `/_apis/work/processes/` +
        `${encodeURIComponent(SOURCE_PROCESS_ID)}` +
        `/workItemTypes/` +
        `${encodeURIComponent(referenceName)}`;
 
    const response =
        await api.get(url);
 
    return response.data;
}
 
/*
 * ------------------------------------------------------------
 * GET ALL FIELDS FOR WIT
 * ------------------------------------------------------------
 *
 * Azure DevOps documented endpoint:
 *
 * GET
 * /_apis/work/processes/{processId}
 * /workItemTypes/{witRefName}/fields
 *
 * This is the dynamic part of the migration.
 * ------------------------------------------------------------
 */
 
async function getWitFields(
    referenceName
) {
 
    const url =
        `/_apis/work/processes/` +
        `${encodeURIComponent(SOURCE_PROCESS_ID)}` +
        `/workItemTypes/` +
        `${encodeURIComponent(referenceName)}` +
        `/fields`;
 
    const response =
        await api.get(url);
 
    return response.data.value || [];
}
 
/*
 * ------------------------------------------------------------
 * GET STATES
 * ------------------------------------------------------------
 */
 
async function getWitStates(
    referenceName
) {
 
    const url =
        `/_apis/work/processes/` +
        `${encodeURIComponent(SOURCE_PROCESS_ID)}` +
        `/workItemTypes/` +
        `${encodeURIComponent(referenceName)}` +
        `/states`;
 
    const response =
        await api.get(url);
 
    return response.data.value || [];
}
 
/*
 * ------------------------------------------------------------
 * GET RULES
 * ------------------------------------------------------------
 */
 
async function getWitRules(
    referenceName
) {
 
    const url =
        `/_apis/work/processes/` +
        `${encodeURIComponent(SOURCE_PROCESS_ID)}` +
        `/workItemTypes/` +
        `${encodeURIComponent(referenceName)}` +
        `/rules`;
 
    const response =
        await api.get(url);
 
    return response.data.value || [];
}
 
/*
 * ------------------------------------------------------------
 * GET FORM LAYOUT
 * ------------------------------------------------------------
 */
 
async function getWitLayout(
    referenceName
) {
 
    const url =
        `/_apis/work/processes/` +
        `${encodeURIComponent(SOURCE_PROCESS_ID)}` +
        `/workItemTypes/` +
        `${encodeURIComponent(referenceName)}` +
        `/layout`;
 
    const response =
        await api.get(url);
 
    return response.data || null;
}
 
/*
 * ------------------------------------------------------------
 * CUSTOM FIELD DETECTION
 * ------------------------------------------------------------
 *
 * IMPORTANT:
 *
 * We do NOT have:
 *
 *   Custom.Role
 *   Custom.TaskDatas1
 *   Custom.TaskDatas2
 *   ...
 *
 * anywhere in this code.
 *
 * Any field whose reference name begins with Custom.
 * is discovered automatically.
 * ------------------------------------------------------------
 */
 
function isCustomField(field) {
 
    if (
        !field ||
        !field.referenceName
    ) {
        return false;
    }
 
    return field.referenceName
        .toLowerCase()
        .startsWith("custom.");
}
 
/*
 * ------------------------------------------------------------
 * NORMALIZE FIELD
 * ------------------------------------------------------------
 */
 
function normalizeField(field) {
 
    return {
 
        referenceName:
            field.referenceName,
 
        name:
            field.name || "",
 
        type:
            field.type || null,
 
        description:
            field.description || "",
 
        required:
            field.required === true,
 
        readOnly:
            field.readOnly === true,
 
        allowGroups:
            field.allowGroups === true,
 
        defaultValue:
            field.defaultValue !== undefined
                ? field.defaultValue
                : null,
 
        allowedValues:
            Array.isArray(field.allowedValues)
                ? field.allowedValues
                : [],
 
        customization:
            field.customization || null,
 
        isLocked:
            field.isLocked === true
    };
}
 
/*
 * ------------------------------------------------------------
 * EXPORT CUSTOM FIELDS
 * ------------------------------------------------------------
 */
 
async function exportCustomFields(
    witReferenceName
) {
 
    const fields =
        await getWitFields(
            witReferenceName
        );
 
    log(
        `Total fields discovered: ${fields.length}`
    );
 
    const customFields =
        fields
            .filter(isCustomField)
            .map(normalizeField);
 
    log(
        `Custom fields discovered: ${customFields.length}`
    );
 
    for (
        const field of customFields
    ) {
 
        log(
            `  ${field.referenceName} | ` +
            `${field.type} | ` +
            `${field.name}`
        );
    }
 
    return customFields;
}
 
/*
 * ------------------------------------------------------------
 * NORMALIZE STATES
 * ------------------------------------------------------------
 */
 
function normalizeStates(
    states
) {
 
    return states.map(
        state => ({
 
            id:
                state.id || null,
 
            name:
                state.name,
 
            color:
                state.color || null,
 
            stateCategory:
                state.stateCategory ||
                state.category ||
                null,
 
            order:
                state.order,
 
            customizationType:
                state.customizationType ||
                null,
 
            hidden:
                state.hidden === true
        })
    );
}
 
/*
 * ------------------------------------------------------------
 * NORMALIZE RULES
 * ------------------------------------------------------------
 */
 
function normalizeRules(
    rules
) {
 
    return rules.map(
        rule => {
 
            const copy =
                JSON.parse(
                    JSON.stringify(rule)
                );
 
            /*
             * IDs belong to source process.
             *
             * Target must receive a new ID.
             */
            delete copy.id;
 
            /*
             * Remove source URLs.
             */
            delete copy.url;
 
            return copy;
        }
    );
}
 
/*
 * ------------------------------------------------------------
 * NORMALIZE LAYOUT
 * ------------------------------------------------------------
 */
 
function normalizeLayout(
    layout
) {
 
    if (!layout) {
        return null;
    }
 
    return JSON.parse(
        JSON.stringify(layout)
    );
}
 
/*
 * ------------------------------------------------------------
 * EXPORT ONE WIT
 * ------------------------------------------------------------
 */
 
async function exportWit(
    witName
) {
 
    log("");
    log(
        "============================================================"
    );
 
    log(
        `Exporting: ${witName}`
    );
 
    log(
        "============================================================"
    );
 
    const wit =
        await resolveWit(
            witName
        );
 
    const referenceName =
        wit.referenceName;
 
    const [
        details,
        customFields,
        states,
        rules,
        layout
    ] =
        await Promise.all([
 
            getWitDetails(
                referenceName
            ),
 
            exportCustomFields(
                referenceName
            ),
 
            getWitStates(
                referenceName
            ),
 
            getWitRules(
                referenceName
            ),
 
            getWitLayout(
                referenceName
            )
        ]);
 
    const exported = {
 
        exportVersion:
            "3.0",
 
        exportedAt:
            new Date().toISOString(),
 
        source: {
 
            organization:
                ORGANIZATION,
 
            url:
                ADO_URL,
 
            project:
                PROJECT,
 
            processId:
                SOURCE_PROCESS_ID,
 
            processName:
                "Sandbox"
        },
 
        workItemType: {
 
            name:
                details.name,
 
            referenceName:
                details.referenceName,
 
            description:
                details.description || "",
 
            color:
                details.color || null,
 
            icon:
                details.icon || null,
 
            inherits:
                details.inherits || null,
 
            customization:
                details.customization || null,
 
            isDisabled:
                details.isDisabled === true
        },
 
        customFields,
 
        states:
            normalizeStates(
                states
            ),
 
        rules:
            normalizeRules(
                rules
            ),
 
        layout:
            normalizeLayout(
                layout
            )
    };
 
    const outputFile =
        path.join(
            OUTPUT_DIR,
            `${safeFileName(witName)}.json`
        );
 
    fs.writeFileSync(
        outputFile,
        JSON.stringify(
            exported,
            null,
            2
        ),
        "utf8"
    );
 
    log(
        `Exported: ${outputFile}`
    );
 
    log(
        `Fields : ${customFields.length}`
    );
 
    log(
        `States : ${states.length}`
    );
 
    log(
        `Rules  : ${rules.length}`
    );
 
    log(
        `Layout : ${layout ? "YES" : "NO"}`
    );
 
    return {
 
        witName,
 
        referenceName,
 
        outputFile,
 
        customFieldCount:
            customFields.length,
 
        stateCount:
            states.length,
 
        ruleCount:
            rules.length,
 
        hasLayout:
            Boolean(layout)
    };
}
 
/*
 * ------------------------------------------------------------
 * MAIN
 * ------------------------------------------------------------
 */
 
async function main() {
 
    validateEnvironment();
 
    ensureOutputDirectory();
 
    log(
        "============================================================"
    );
 
    log(
        "AZURE DEVOPS DYNAMIC PROCESS EXPORT"
    );
 
    log(
        "============================================================"
    );
 
    log(
        `Organization : ${ORGANIZATION}`
    );
 
    log(
        `Project      : ${PROJECT}`
    );
 
    log(
        `Source PID   : ${SOURCE_PROCESS_ID}`
    );
 
    log(
        `WIT count    : ${WITS.length}`
    );
 
    log("");
 
    const results = [];
 
    for (
        const witName of WITS
    ) {
 
        try {
 
            const result =
                await exportWit(
                    witName
                );
 
            results.push(
                result
            );
 
        } catch (error) {
 
            console.error("");
            console.error(
                `[ERROR] Failed to export '${witName}'`
            );
 
            printApiError(
                error
            );
 
            throw error;
        }
    }
 
    log("");
    log(
        "============================================================"
    );
 
    log(
        "EXPORT SUMMARY"
    );
 
    log(
        "============================================================"
    );
 
    for (
        const result of results
    ) {
 
        log(
            `${result.witName}: ` +
            `${result.customFieldCount} custom fields, ` +
            `${result.stateCount} states, ` +
            `${result.ruleCount} rules, ` +
            `layout=${result.hasLayout}`
        );
    }
 
    log("");
    log(
        "DEV EXPORT COMPLETED SUCCESSFULLY"
    );
 
    log(
        "============================================================"
    );
}
 
/*
 * ------------------------------------------------------------
 * START
 * ------------------------------------------------------------
 */
 
main().catch(
    error => {
 
        console.error("");
        console.error(
            "[FATAL] Export failed."
        );
 
        printApiError(
            error
        );
 
        process.exit(1);
    }
);
