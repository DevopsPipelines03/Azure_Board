// "use strict";

// const axios = require("axios");
// const fs = require("fs");
// const path = require("path");

// /*
//  * ============================================================
//  * Azure DevOps - Same Process WIT Export
//  * ============================================================
//  *
//  * SOURCE:
//  *   Interview Evaluation
//  *   Interview Task
//  *
//  * TARGET:
//  *   Interview Requirement
//  *   Interview Data
//  *
//  * IMPORTANT:
//  *   Both source and target WITs belong to the SAME PROCESS.
//  *
//  * Required environment variables:
//  *
//  *   ADO_ORG
//  *   ADO_PAT
//  *   SOURCE_PROCESS_ID
//  *
//  * Optional:
//  *
//  *   API_VERSION
//  *   RUNTIME_DIR
//  *
//  * Output:
//  *
//  *   runtime/interview-evaluation.json
//  *   runtime/interview-task.json
//  *   runtime/migration-map.json
//  *
//  * ============================================================
//  */

// const API_VERSION = process.env.API_VERSION || "7.1";

// const ADO_ORG = process.env.ADO_ORG;
// const ADO_PAT = process.env.ADO_PAT;
// const SOURCE_PROCESS_ID = process.env.SOURCE_PROCESS_ID;

// const RUNTIME_DIR = path.resolve(
//     process.env.RUNTIME_DIR || path.join(process.cwd(), "runtime")
// );

// /*
//  * FINAL WIT MAPPING
//  */
// // const WIT_MAPPINGS = [
// //     {
// //         sourceName: "Interview Evaluation",
// //         targetName: "Interview Requirement",
// //         outputFile: "interview-evaluation.json"
// //     },
// //     {
// //         sourceName: "Interview Task",
// //         targetName: "Interview Data",
// //         outputFile: "interview-task.json"
// //     }
// // ];
// const WIT_MAPPINGS = [
//     {
//         sourceName: "Interview Requirement",
//         targetName: "Role Task Interview",
//         outputFile: "interview-requirement.json"
//     },
//     {
//         sourceName: "Interview",
//         targetName: "ROI BVF Scoring Interview",
//         outputFile: "interview.json"
//     }
// ];

// /*
//  * ------------------------------------------------------------
//  * Validation
//  * ------------------------------------------------------------
//  */

// function validateEnvironment() {
//     const missing = [];

//     if (!ADO_ORG) {
//         missing.push("ADO_ORG");
//     }

//     if (!ADO_PAT) {
//         missing.push("ADO_PAT");
//     }

//     if (!SOURCE_PROCESS_ID) {
//         missing.push("SOURCE_PROCESS_ID");
//     }

//     if (missing.length > 0) {
//         throw new Error(
//             `Missing required environment variables: ${missing.join(", ")}`
//         );
//     }
// }

// /*
//  * ------------------------------------------------------------
//  * Axios client
//  * ------------------------------------------------------------
//  */

// function createClient() {
//     const auth = Buffer
//         .from(`:${ADO_PAT}`)
//         .toString("base64");

//     return axios.create({
//         baseURL: `https://dev.azure.com/${ADO_ORG}`,
//         headers: {
//             Authorization: `Basic ${auth}`,
//             Accept: "application/json",
//             "Content-Type": "application/json"
//         },
//         timeout: 60000
//     });
// }

// const client = createClient();

// /*
//  * ------------------------------------------------------------
//  * Helpers
//  * ------------------------------------------------------------
//  */

// function processUrl(processId, suffix = "") {
//     return `/_apis/work/processes/${encodeURIComponent(processId)}${suffix}`;
// }

// function witUrl(processId, witRefName, suffix = "") {
//     return processUrl(
//         processId,
//         `/workItemTypes/${encodeURIComponent(witRefName)}${suffix}`
//     );
// }

// async function get(url) {
//     try {
//         const response = await client.get(url, {
//             params: {
//                 "api-version": API_VERSION
//             }
//         });

//         return response.data;
//     } catch (error) {
//         printAxiosError(`GET ${url}`, error);
//         throw error;
//     }
// }

// function printAxiosError(operation, error) {
//     console.error(`\n[ERROR] ${operation}`);

//     if (error.response) {
//         console.error(`HTTP Status: ${error.response.status}`);

//         if (error.response.data) {
//             console.error(
//                 JSON.stringify(error.response.data, null, 2)
//             );
//         }
//     } else {
//         console.error(error.message);
//     }
// }

// /*
//  * ------------------------------------------------------------
//  * Find WIT by DISPLAY NAME
//  * ------------------------------------------------------------
//  *
//  * We intentionally resolve the referenceName from the process.
//  *
//  * We NEVER assume:
//  *
//  *   InterviewEvaluation
//  *   InterviewTask
//  *
//  * as the API reference name.
//  * ------------------------------------------------------------
//  */

// async function listWorkItemTypes() {
//     const url = processUrl(
//         SOURCE_PROCESS_ID,
//         "/workItemTypes"
//     );

//     const data = await get(url);

//     return Array.isArray(data.value)
//         ? data.value
//         : [];
// }

// async function findSourceWit(sourceName) {
//     const workItemTypes = await listWorkItemTypes();

//     const wit = workItemTypes.find(
//         item =>
//             String(item.name || "")
//                 .trim()
//                 .toLowerCase() ===
//             sourceName.trim().toLowerCase()
//     );

//     if (!wit) {
//         throw new Error(
//             `Source WIT "${sourceName}" was not found in process ${SOURCE_PROCESS_ID}.`
//         );
//     }

//     console.log(
//         `  Source WIT: ${wit.name}`
//     );

//     console.log(
//         `  Source referenceName: ${wit.referenceName}`
//     );

//     return wit;
// }

// /*
//  * ------------------------------------------------------------
//  * Export WIT definition
//  * ------------------------------------------------------------
//  */

// async function exportWit(mapping) {
//     console.log("\n================================================");
//     console.log(`EXPORT: ${mapping.sourceName}`);
//     console.log(`TARGET: ${mapping.targetName}`);
//     console.log("================================================");

//     const sourceWit = await findSourceWit(mapping.sourceName);

//     const sourceRefName = sourceWit.referenceName;

//     /*
//      * Work item type metadata
//      */
//     const wit = await get(
//         witUrl(
//             SOURCE_PROCESS_ID,
//             sourceRefName
//         )
//     );

//     /*
//      * Fields
//      */
//     console.log("  Reading fields...");

//     const fields = await get(
//         witUrl(
//             SOURCE_PROCESS_ID,
//             sourceRefName,
//             "/fields"
//         )
//     );

//     /*
//      * States
//      */
//     console.log("  Reading states...");

//     const states = await get(
//         witUrl(
//             SOURCE_PROCESS_ID,
//             sourceRefName,
//             "/states"
//         )
//     );

//     /*
//      * Rules
//      */
//     console.log("  Reading rules...");

//     const rules = await get(
//         witUrl(
//             SOURCE_PROCESS_ID,
//             sourceRefName,
//             "/rules"
//         )
//     );

//     /*
//      * Layout
//      */
//     console.log("  Reading layout...");

//     const layout = await get(
//         witUrl(
//             SOURCE_PROCESS_ID,
//             sourceRefName,
//             "/layout"
//         )
//     );

//     /*
//      * Build export document
//      */
//     const exportData = {
//         schemaVersion: 2,

//         exportedAt: new Date().toISOString(),

//         apiVersion: API_VERSION,

//         process: {
//             id: SOURCE_PROCESS_ID
//         },

//         source: {
//             name: mapping.sourceName,
//             referenceName: sourceRefName
//         },

//         target: {
//             name: mapping.targetName
//         },

//         workItemType: {
//             referenceName: wit.referenceName,
//             name: wit.name,
//             description: wit.description || "",
//             color: wit.color || null,
//             icon: wit.icon || null,
//             isDisabled: wit.isDisabled || false
//         },

//         fields: Array.isArray(fields.value)
//             ? fields.value
//             : [],

//         states: Array.isArray(states.value)
//             ? states.value
//             : [],

//         rules: Array.isArray(rules.value)
//             ? rules.value
//             : [],

//         layout: layout || {
//             pages: [],
//             systemControls: [],
//             extensions: []
//         }
//     };

//     const outputPath = path.join(
//         RUNTIME_DIR,
//         mapping.outputFile
//     );

//     fs.writeFileSync(
//         outputPath,
//         JSON.stringify(exportData, null, 2),
//         "utf8"
//     );

//     console.log(
//         `\n  Exported: ${outputPath}`
//     );

//     console.log(
//         `  Fields : ${exportData.fields.length}`
//     );

//     console.log(
//         `  States : ${exportData.states.length}`
//     );

//     console.log(
//         `  Rules  : ${exportData.rules.length}`
//     );

//     console.log(
//         `  Pages  : ${
//             Array.isArray(exportData.layout.pages)
//                 ? exportData.layout.pages.length
//                 : 0
//         }`
//     );

//     return exportData;
// }

// /*
//  * ------------------------------------------------------------
//  * Main
//  * ------------------------------------------------------------
//  */

// async function main() {
//     console.log("\n================================================");
//     console.log("Azure DevOps Same-Process WIT Export");
//     console.log("================================================");

//     validateEnvironment();

//     fs.mkdirSync(
//         RUNTIME_DIR,
//         {
//             recursive: true
//         }
//     );

//     console.log(`Organization : ${ADO_ORG}`);
//     console.log(`Process ID   : ${SOURCE_PROCESS_ID}`);
//     console.log(`Runtime      : ${RUNTIME_DIR}`);

//     const results = [];

//     for (const mapping of WIT_MAPPINGS) {
//         const result = await exportWit(mapping);
//         results.push(result);
//     }

//     /*
//      * Create a small migration map as well.
//      */
//     const migrationMap = {
//         schemaVersion: 1,
//         exportedAt: new Date().toISOString(),
//         processId: SOURCE_PROCESS_ID,

//         mappings: results.map(item => ({
//             sourceName: item.source.name,
//             sourceReferenceName: item.source.referenceName,
//             targetName: item.target.name
//         }))
//     };

//     const mapPath = path.join(
//         RUNTIME_DIR,
//         "migration-map.json"
//     );

//     fs.writeFileSync(
//         mapPath,
//         JSON.stringify(
//             migrationMap,
//             null,
//             2
//         ),
//         "utf8"
//     );

//     console.log("\n================================================");
//     console.log("EXPORT COMPLETED");
//     console.log("================================================");

//     console.log(
//         `Migration map: ${mapPath}`
//     );

//     for (const item of migrationMap.mappings) {
//         console.log(
//             `  ${item.sourceName} -> ${item.targetName}`
//         );
//     }
// }

// main().catch(error => {
//     console.error("\nEXPORT FAILED");

//     console.error(
//         error.message
//     );

//     process.exit(1);
// });








// =================================================================================
// Be Careful: Email is from an External Source 
// Use caution when opening emails and do not click on links or attachments from unknown senders. For more resources, visit security.cat.com/phishing. 


"use strict";

const fs = require("fs");
const path = require("path");
const axios = require("axios");

/*
|--------------------------------------------------------------------------
| CONFIGURATION
|--------------------------------------------------------------------------
|
| Same-process WIT cloning:
|
| Interview Evaluation -> Interview Requirement
| Interview Task       -> Interview Data
|
| Required environment variables:
|
|   ADO_ORG
|   ADO_PAT
|   SOURCE_PROCESS_ID
|   MIGRATION_MODE
|
| MIGRATION_MODE:
|   dry-run
|   apply
|
|--------------------------------------------------------------------------
*/

const API_VERSION = "7.1";

const ORG = process.env.ADO_ORG;
const PAT = process.env.ADO_PAT;
const PROCESS_ID = process.env.SOURCE_PROCESS_ID;
const MODE = (process.env.MIGRATION_MODE || "dry-run").trim();

const RUNTIME_DIR = path.join(__dirname, "..", "runtime");

// const WIT_MAPPINGS = [
//     {
//         sourceName: "Interview Evaluation",
//         targetName: "Interview Requirement",
//         file: "interview-evaluation.json"
//     },
//     {
//         sourceName: "Interview Task",
//         targetName: "Interview Data",
//         file: "interview-task.json"
//     }
// ];
const WIT_MAPPINGS = [
    {
        sourceName: "Interview Requirement",
        targetName: "Role Task Interview",
        outputFile: "interview-requirement.json"
    },
    {
        sourceName: "Interview",
        targetName: "ROI BVF Scoring Interview",
        outputFile: "interview.json"
    }
];


/*
|--------------------------------------------------------------------------
| VALIDATION
|--------------------------------------------------------------------------
*/

function validateEnvironment() {
    const missing = [];

    if (!ORG) missing.push("ADO_ORG");
    if (!PAT) missing.push("ADO_PAT");
    if (!PROCESS_ID) missing.push("SOURCE_PROCESS_ID");

    if (missing.length > 0) {
        throw new Error(
            `Missing required environment variables: ${missing.join(", ")}`
        );
    }

    if (!["dry-run", "apply"].includes(MODE)) {
        throw new Error(
            `Invalid MIGRATION_MODE: ${MODE}. Use "dry-run" or "apply".`
        );
    }

    if (!fs.existsSync(RUNTIME_DIR)) {
        throw new Error(
            `Runtime directory does not exist: ${RUNTIME_DIR}`
        );
    }
}

/*
|--------------------------------------------------------------------------
| AXIOS
|--------------------------------------------------------------------------
*/

const api = axios.create({
    baseURL: `https://dev.azure.com/${ORG}`,
    auth: {
        username: "",
        password: PAT
    },
    headers: {
        "Content-Type": "application/json"
    },
    params: {
        "api-version": API_VERSION
    },
    timeout: 120000
});

/*
|--------------------------------------------------------------------------
| LOGGING
|--------------------------------------------------------------------------
*/

function log(message = "") {
    console.log(message);
}

function info(message) {
    console.log(`[INFO] ${message}`);
}

function warn(message) {
    console.log(`[WARN] ${message}`);
}

function error(message) {
    console.error(`[ERROR] ${message}`);
}

function separator(char = "-", length = 74) {
    console.log(char.repeat(length));
}

/*
|--------------------------------------------------------------------------
| ERROR HELPERS
|--------------------------------------------------------------------------
*/

function getErrorMessage(err) {
    if (!err) {
        return "Unknown error";
    }

    if (err.response) {
        const status = err.response.status;

        const data = err.response.data;

        let detail = "";

        if (typeof data === "string") {
            detail = data;
        } else if (data?.message) {
            detail = data.message;
        } else if (data?.error?.message) {
            detail = data.error.message;
        } else {
            try {
                detail = JSON.stringify(data);
            } catch {
                detail = String(data);
            }
        }

        return `HTTP ${status}: ${detail}`;
    }

    return err.message || String(err);
}

function isDuplicateRuleError(err) {
    const message = getErrorMessage(err).toLowerCase();

    return (
        message.includes("vs1640126") ||
        message.includes("duplicate of this rule") ||
        message.includes("duplicate rule")
    );
}

function isAlreadyExistsError(err) {
    const message = getErrorMessage(err).toLowerCase();

    return (
        message.includes("already exists") ||
        message.includes("duplicate")
    );
}

/*
|--------------------------------------------------------------------------
| URL HELPERS
|--------------------------------------------------------------------------
*/

function enc(value) {
    return encodeURIComponent(value);
}

function processBase() {
    return `/_apis/work/processes/${enc(PROCESS_ID)}`;
}

function witBase(witRefName) {
    return `${processBase()}/workitemtypes/${enc(witRefName)}`;
}

/*
|--------------------------------------------------------------------------
| HTTP HELPERS
|--------------------------------------------------------------------------
*/

async function get(url) {
    const response = await api.get(url);
    return response.data;
}

async function post(url, body) {
    const response = await api.post(url, body);
    return response.data;
}

/*
|--------------------------------------------------------------------------
| GENERIC HELPERS
|--------------------------------------------------------------------------
*/

function normalize(value) {
    if (value === undefined || value === null) {
        return "";
    }

    return String(value)
        .trim()
        .toLowerCase();
}

function hasValue(value) {
    return value !== undefined && value !== null && value !== "";
}

function isCustomField(field) {
    return (
        typeof field?.referenceName === "string" &&
        field.referenceName.startsWith("Custom.")
    );
}

function isInherited(node) {
    return node?.inherited === true;
}

function isCustomNode(node) {
    return node && node.inherited !== true;
}

function safeArray(value) {
    return Array.isArray(value) ? value : [];
}

/*
|--------------------------------------------------------------------------
| FILE HELPERS
|--------------------------------------------------------------------------
*/

function loadRuntimeFile(fileName) {
    const fullPath = path.join(RUNTIME_DIR, fileName);

    if (!fs.existsSync(fullPath)) {
        throw new Error(`Runtime file not found: ${fullPath}`);
    }

    try {
        return JSON.parse(fs.readFileSync(fullPath, "utf8"));
    } catch (err) {
        throw new Error(
            `Unable to parse runtime file ${fullPath}: ${err.message}`
        );
    }
}

/*
|--------------------------------------------------------------------------
| PROCESS / WIT
|--------------------------------------------------------------------------
*/

async function listWits() {
    const url =
        `${processBase()}/workitemtypes` +
        `?$expand=layout`;

    const data = await get(url);

    return safeArray(data?.value);
}

async function findWitByName(name) {
    const wits = await listWits();

    return (
        wits.find(
            wit => normalize(wit.name) === normalize(name)
        ) || null
    );
}

async function createTargetWit(sourceWit, targetName) {
    if (MODE === "dry-run") {
        info(
            `[DRY-RUN] Would create target WIT: ${targetName}`
        );

        return {
            name: targetName,
            referenceName: null,
            created: true
        };
    }

    const body = {
        name: targetName,
        description: sourceWit?.workItemType?.description || "",
        color: sourceWit?.workItemType?.color || "009CCC",
        icon: sourceWit?.workItemType?.icon || "icon_workitem"
    };

    info(`Creating target WIT: ${targetName}`);

    const created = await post(
        `${processBase()}/workitemtypes`,
        body
    );

    return {
        ...created,
        created: true
    };
}

async function resolveTargetWit(targetName, sourceWit) {
    let target = await findWitByName(targetName);

    if (target) {
        info(`Target WIT already exists: ${targetName}`);

        return {
            wit: target,
            created: false
        };
    }

    if (MODE === "dry-run") {
        const simulatedReferenceName =
            `${sourceWit?.workItemType?.referenceName || "Custom"}.${targetName
                .replace(/\s+/g, "")}`;

        return {
            wit: {
                name: targetName,
                referenceName: simulatedReferenceName
            },
            created: true
        };
    }

    await createTargetWit(sourceWit, targetName);

    /*
     * IMPORTANT:
     *
     * Never calculate the reference name ourselves.
     * Azure DevOps owns the real reference name.
     */
    target = await findWitByName(targetName);

    if (!target) {
        throw new Error(
            `Target WIT was created but could not be resolved: ${targetName}`
        );
    }

    return {
        wit: target,
        created: true
    };
}

/*
|--------------------------------------------------------------------------
| FIELDS
|--------------------------------------------------------------------------
*/

async function getWitFields(witRefName) {
    const url =
        `${witBase(witRefName)}/fields` +
        `?$expand=all`;

    const data = await get(url);

    return safeArray(data?.value);
}

function buildFieldMap(fields) {
    const map = new Map();

    for (const field of safeArray(fields)) {
        if (!field?.referenceName) {
            continue;
        }

        map.set(
            normalize(field.referenceName),
            field
        );
    }

    return map;
}

function buildFieldPayload(sourceField) {
    const payload = {
        referenceName: sourceField.referenceName,
        name: sourceField.name,
        type: sourceField.type,
        description: sourceField.description || "",
        required: sourceField.required === true,
        readOnly: sourceField.readOnly === true
    };

    if (sourceField.allowGroups !== undefined) {
        payload.allowGroups = sourceField.allowGroups;
    }

    if (Array.isArray(sourceField.allowedValues)) {
        payload.allowedValues = sourceField.allowedValues;
    }

    if (sourceField.type === "boolean") {
        /*
         * Azure DevOps requires Boolean fields to have a default.
         */
        payload.defaultValue =
            sourceField.defaultValue !== undefined &&
            sourceField.defaultValue !== null
                ? sourceField.defaultValue
                : false;
    } else if (
        sourceField.defaultValue !== undefined &&
        sourceField.defaultValue !== null
    ) {
        payload.defaultValue = sourceField.defaultValue;
    }

    return payload;
}

async function migrateFields(
    sourceFields,
    targetWitRefName,
    stats
) {
    separator();
    log("FIELDS");

    const sourceCustomFields = safeArray(sourceFields)
        .filter(isCustomField);

    let targetFields = [];

    if (MODE === "apply") {
        targetFields = await getWitFields(targetWitRefName);
    }

    let targetFieldMap = buildFieldMap(targetFields);

    for (const sourceField of sourceCustomFields) {
        const ref = sourceField.referenceName;

        const existing =
            targetFieldMap.get(normalize(ref));

        if (existing) {
            info(`Field already exists: ${ref}`);
            stats.fields.existing++;
            continue;
        }

        if (MODE === "dry-run") {
            info(`[DRY-RUN] Would create field: ${ref}`);
            stats.fields.created++;

            continue;
        }

        try {
            const payload = buildFieldPayload(sourceField);

            await post(
                `${witBase(targetWitRefName)}/fields`,
                payload
            );

            info(`Field created: ${ref}`);

            stats.fields.created++;

            /*
             * Refresh local map so later fields see the new field.
             */
            targetFields = await getWitFields(targetWitRefName);
            targetFieldMap = buildFieldMap(targetFields);

        } catch (err) {
            /*
             * Another run/process may have created the field.
             * Re-check before marking failure.
             */
            try {
                targetFields =
                    await getWitFields(targetWitRefName);

                targetFieldMap =
                    buildFieldMap(targetFields);

                if (
                    targetFieldMap.has(normalize(ref))
                ) {
                    info(
                        `Field already exists after retry: ${ref}`
                    );

                    stats.fields.existing++;
                    continue;
                }
            } catch {
                // Ignore refresh error and report original error.
            }

            error(
                `Field failed: ${ref} -> ${getErrorMessage(err)}`
            );

            stats.fields.failed++;
        }
    }

    /*
     * CRITICAL:
     *
     * Always rebuild the target field map after field migration.
     *
     * This fixes the previous:
     *
     *   "No target field mapping found"
     *
     * problem when all fields already existed.
     */
    if (MODE === "apply") {
        targetFields = await getWitFields(targetWitRefName);
    } else {
        targetFields = safeArray(sourceFields)
            .filter(field => {
                return (
                    !field.referenceName ||
                    !field.referenceName.startsWith("Custom.") ||
                    sourceCustomFields.some(
                        f =>
                            f.referenceName ===
                            field.referenceName
                    )
                );
            });
    }

    return {
        fields: targetFields,
        map: buildFieldMap(targetFields)
    };
}

/*
|--------------------------------------------------------------------------
| STATES
|--------------------------------------------------------------------------
*/

async function getStates(witRefName) {
    const data = await get(
        `${witBase(witRefName)}/states`
    );

    return safeArray(data?.value);
}

async function migrateStates(
    sourceStates,
    targetWitRefName,
    stats
) {
    separator();
    log("STATES");

    let targetStates =
        MODE === "apply"
            ? await getStates(targetWitRefName)
            : [];

    const targetMap = new Map();

    for (const state of targetStates) {
        targetMap.set(
            normalize(state.name),
            state
        );
    }

    for (const sourceState of safeArray(sourceStates)) {
        const stateName = sourceState.name;

        if (targetMap.has(normalize(stateName))) {
            info(`State already exists: ${stateName}`);
            stats.states.existing++;
            continue;
        }

        if (MODE === "dry-run") {
            info(
                `[DRY-RUN] Would create state: ${stateName}`
            );

            stats.states.created++;
            continue;
        }

        try {
            /*
             * Do NOT send order.
             *
             * Azure DevOps assigns the order.
             */
            const payload = {
                name: stateName,
                color: sourceState.color || "FFFFFF",
                stateCategory:
                    sourceState.stateCategory || "Proposed"
            };

            await post(
                `${witBase(targetWitRefName)}/states`,
                payload
            );

            info(`State created: ${stateName}`);

            stats.states.created++;

            targetStates =
                await getStates(targetWitRefName);

            targetMap.clear();

            for (const state of targetStates) {
                targetMap.set(
                    normalize(state.name),
                    state
                );
            }

        } catch (err) {
            /*
             * Re-check in case another execution created it.
             */
            try {
                targetStates =
                    await getStates(targetWitRefName);

                const exists =
                    targetStates.some(
                        s =>
                            normalize(s.name) ===
                            normalize(stateName)
                    );

                if (exists) {
                    info(
                        `State already exists after retry: ${stateName}`
                    );

                    stats.states.existing++;
                    continue;
                }
            } catch {
                // Ignore secondary lookup error.
            }

            error(
                `State failed: ${stateName} -> ${getErrorMessage(err)}`
            );

            stats.states.failed++;
        }
    }
}

/*
|--------------------------------------------------------------------------
| RULES
|--------------------------------------------------------------------------
*/

async function getRules(witRefName) {
    const data = await get(
        `${witBase(witRefName)}/rules`
    );

    return safeArray(data?.value);
}

function cloneAndTransform(value, sourceRef, targetRef) {
    if (Array.isArray(value)) {
        return value.map(item =>
            cloneAndTransform(
                item,
                sourceRef,
                targetRef
            )
        );
    }

    if (
        value &&
        typeof value === "object"
    ) {
        const result = {};

        for (const [key, child] of Object.entries(value)) {
            result[key] =
                cloneAndTransform(
                    child,
                    sourceRef,
                    targetRef
                );
        }

        return result;
    }

    if (value === sourceRef) {
        return targetRef;
    }

    return value;
}

function buildRulePayload(
    sourceRule,
    sourceRef,
    targetRef
) {
    const transformed =
        cloneAndTransform(
            sourceRule,
            sourceRef,
            targetRef
        );

    /*
     * These are server-owned properties.
     */
    delete transformed.id;
    delete transformed.url;
    delete transformed.customizationType;
    delete transformed.inherited;
    delete transformed.overridden;

    return transformed;
}

async function migrateRules(
    sourceRules,
    targetWitRefName,
    sourceWitRefName,
    stats
) {
    separator();
    log("RULES");

    let targetRules =
        MODE === "apply"
            ? await getRules(targetWitRefName)
            : [];

    let targetRuleMap = new Map();

    for (const rule of targetRules) {
        if (rule?.name) {
            targetRuleMap.set(
                normalize(rule.name),
                rule
            );
        }
    }

    for (const sourceRule of safeArray(sourceRules)) {
        if (!sourceRule?.name) {
            continue;
        }

        /*
         * Never migrate inherited/system rules.
         */
        if (
            sourceRule.customizationType &&
            sourceRule.customizationType !== "custom"
        ) {
            info(
                `Skipping non-custom rule: ${sourceRule.name}`
            );

            stats.rules.existing++;
            continue;
        }

        const ruleName = sourceRule.name;

        if (
            targetRuleMap.has(
                normalize(ruleName)
            )
        ) {
            info(`Rule already exists: ${ruleName}`);
            stats.rules.existing++;
            continue;
        }

        if (MODE === "dry-run") {
            info(
                `[DRY-RUN] Would create rule: ${ruleName}`
            );

            stats.rules.created++;
            continue;
        }

        try {
            const payload =
                buildRulePayload(
                    sourceRule,
                    sourceWitRefName,
                    targetWitRefName
                );

            await post(
                `${witBase(targetWitRefName)}/rules`,
                payload
            );

            info(`Rule created: ${ruleName}`);

            stats.rules.created++;

            targetRules =
                await getRules(targetWitRefName);

            targetRuleMap = new Map();

            for (const rule of targetRules) {
                if (rule?.name) {
                    targetRuleMap.set(
                        normalize(rule.name),
                        rule
                    );
                }
            }

        } catch (err) {
            /*
             * Duplicate rule is not a migration failure.
             *
             * Azure can return duplicate even if the previous GET
             * did not show it because of timing/inheritance behavior.
             */
            if (isDuplicateRuleError(err)) {
                try {
                    const refreshed =
                        await getRules(
                            targetWitRefName
                        );

                    const exists =
                        refreshed.some(
                            rule =>
                                normalize(rule.name) ===
                                normalize(ruleName)
                        );

                    if (exists) {
                        info(
                            `Rule already exists after duplicate response: ${ruleName}`
                        );

                        stats.rules.existing++;
                        continue;
                    }
                } catch {
                    // Continue to failure below.
                }
            }

            error(
                `Rule failed: ${ruleName} -> ${getErrorMessage(err)}`
            );

            stats.rules.failed++;
        }
    }
}

/*
|--------------------------------------------------------------------------
| LAYOUT
|--------------------------------------------------------------------------
*/

async function getLayout(witRefName) {
    return await get(
        `${witBase(witRefName)}/layout`
    );
}

function getPages(layout) {
    return safeArray(layout?.pages);
}

function getSections(page) {
    return safeArray(page?.sections);
}

function getGroups(section) {
    return safeArray(section?.groups);
}

function getControls(group) {
    return safeArray(group?.controls);
}

/*
|--------------------------------------------------------------------------
| LAYOUT FIELD RESOLUTION
|--------------------------------------------------------------------------
*/

function resolveSourceFieldReference(
    control,
    sourceFieldMap
) {
    if (!control) {
        return null;
    }

    /*
     * Official Azure layout uses the field reference name
     * directly as the control id:
     *
     *   System.Title
     *   System.State
     *   Custom.Role
     *
     * Therefore this is our primary lookup.
     */
    const candidates = [
        control.id,
        control.referenceName,
        control.fieldReferenceName
    ];

    for (const candidate of candidates) {
        if (!candidate) {
            continue;
        }

        const key = normalize(candidate);

        if (sourceFieldMap.has(key)) {
            return sourceFieldMap.get(key).referenceName;
        }
    }

    /*
     * Contribution controls can reference fields through
     * contribution.inputs.FieldName.
     */
    const contributionField =
        control?.contribution?.inputs?.FieldName;

    if (contributionField) {
        const key =
            normalize(contributionField);

        if (sourceFieldMap.has(key)) {
            return sourceFieldMap.get(key).referenceName;
        }
    }

    return null;
}

function collectLayoutFieldReferences(
    layout,
    sourceFieldMap
) {
    const result = new Map();

    for (const page of getPages(layout)) {
        for (const section of getSections(page)) {
            for (const group of getGroups(section)) {
                for (const control of getControls(group)) {
                    const fieldRef =
                        resolveSourceFieldReference(
                            control,
                            sourceFieldMap
                        );

                    if (fieldRef) {
                        result.set(
                            normalize(fieldRef),
                            fieldRef
                        );
                    }
                }
            }
        }
    }

    for (const control of safeArray(layout?.systemControls)) {
        const fieldRef =
            resolveSourceFieldReference(
                control,
                sourceFieldMap
            );

        if (fieldRef) {
            result.set(
                normalize(fieldRef),
                fieldRef
            );
        }
    }

    return result;
}

/*
|--------------------------------------------------------------------------
| LAYOUT MATCHING
|--------------------------------------------------------------------------
*/

function findPage(
    targetPages,
    sourcePage,
    sourceIndex
) {
    /*
     * First try exact ID.
     */
    if (sourcePage?.id) {
        const byId =
            targetPages.find(
                page =>
                    page.id &&
                    normalize(page.id) ===
                    normalize(sourcePage.id)
            );

        if (byId) {
            return byId;
        }
    }

    /*
     * Then label.
     */
    if (sourcePage?.label) {
        const byLabel =
            targetPages.find(
                page =>
                    normalize(page.label) ===
                    normalize(sourcePage.label)
            );

        if (byLabel) {
            return byLabel;
        }
    }

    /*
     * Finally use page position for inherited standard pages.
     */
    if (
        sourcePage?.inherited === true &&
        targetPages[sourceIndex]
    ) {
        return targetPages[sourceIndex];
    }

    return null;
}

function findSection(
    targetSections,
    sourceSection,
    sourceIndex
) {
    /*
     * Sections frequently have only IDs and no name/label.
     */

    if (sourceSection?.id) {
        const byId =
            targetSections.find(
                section =>
                    section.id &&
                    normalize(section.id) ===
                    normalize(sourceSection.id)
            );

        if (byId) {
            return byId;
        }
    }

    /*
     * For inherited standard sections, position is reliable
     * because Details/History/Links/Attachments use Section1..4.
     */
    if (
        sourceSection?.inherited === true &&
        targetSections[sourceIndex]
    ) {
        return targetSections[sourceIndex];
    }

    return null;
}

function findGroup(
    targetGroups,
    sourceGroup
) {
    if (sourceGroup?.id) {
        const byId =
            targetGroups.find(
                group =>
                    group.id &&
                    normalize(group.id) ===
                    normalize(sourceGroup.id)
            );

        if (byId) {
            return byId;
        }
    }

    if (sourceGroup?.label) {
        const byLabel =
            targetGroups.find(
                group =>
                    normalize(group.label) ===
                    normalize(sourceGroup.label)
            );

        if (byLabel) {
            return byLabel;
        }
    }

    return null;
}

function controlIdentity(
    control,
    sourceFieldMap
) {
    const fieldRef =
        resolveSourceFieldReference(
            control,
            sourceFieldMap
        );

    if (fieldRef) {
        return `field:${normalize(fieldRef)}`;
    }

    const contributionId =
        control?.contribution?.contributionId;

    if (contributionId) {
        return `contribution:${normalize(contributionId)}`;
    }

    if (control?.id) {
        return `id:${normalize(control.id)}`;
    }

    return `label:${normalize(control?.label)}`;
}

function targetControlIdentity(
    control,
    targetFieldMap
) {
    if (!control) {
        return null;
    }

    /*
     * For a normal FieldControl, id is the field referenceName.
     */
    if (
        normalize(control.controlType) ===
        "fieldcontrol"
    ) {
        const field =
            targetFieldMap.get(
                normalize(control.id)
            );

        if (field) {
            return `field:${normalize(field.referenceName)}`;
        }

        /*
         * Even if the target field map doesn't contain it,
         * the control ID itself may be the reference name.
         */
        if (control.id) {
            return `field:${normalize(control.id)}`;
        }
    }

    const contributionId =
        control?.contribution?.contributionId;

    if (contributionId) {
        return `contribution:${normalize(contributionId)}`;
    }

    if (control?.id) {
        return `id:${normalize(control.id)}`;
    }

    return `label:${normalize(control?.label)}`;
}

function controlAlreadyExists(
    targetControls,
    sourceControl,
    sourceFieldMap,
    targetFieldMap
) {
    const sourceIdentity =
        controlIdentity(
            sourceControl,
            sourceFieldMap
        );

    return targetControls.some(
        targetControl =>
            targetControlIdentity(
                targetControl,
                targetFieldMap
            ) === sourceIdentity
    );
}

/*
|--------------------------------------------------------------------------
| LAYOUT PAYLOADS
|--------------------------------------------------------------------------
*/

function buildPagePayload(sourcePage) {
    const payload = {
        id: "",
        label:
            sourcePage.label ||
            sourcePage.id ||
            "Custom Page",
        order:
            sourcePage.order !== undefined
                ? sourcePage.order
                : null,
        visible:
            sourcePage.visible !== false,
        locked: false,
        pageType:
            sourcePage.pageType || "custom",
        sections: []
    };

    /*
     * Azure accepts sections in the page-create request.
     *
     * Only include IDs. Groups/controls are created separately.
     */
    for (const section of getSections(sourcePage)) {
        payload.sections.push({
            id: section.id || "",
            groups: [],
            overridden: false
        });
    }

    return payload;
}

function buildGroupPayload(sourceGroup) {
    const payload = {
        controls: null,
        id: null,
        label:
            sourceGroup.label ||
            sourceGroup.id ||
            "Custom",
        order:
            sourceGroup.order !== undefined
                ? sourceGroup.order
                : null,
        visible:
            sourceGroup.visible !== false
    };

    if (sourceGroup.isContribution) {
        payload.isContribution = true;

        if (sourceGroup.contribution) {
            payload.contribution =
                sourceGroup.contribution;
        }
    } else {
        payload.isContribution = false;
    }

    return payload;
}

function buildControlPayload(
    sourceControl,
    targetFieldReferenceName
) {
    const payload = {
        order:
            sourceControl.order !== undefined
                ? sourceControl.order
                : null,
        label:
            sourceControl.label || "",
        readOnly:
            sourceControl.readOnly === true,
        visible:
            sourceControl.visible !== false,
        controlType:
            sourceControl.controlType ||
            "FieldControl",
        metadata:
            sourceControl.metadata || null,
        watermark:
            sourceControl.watermark || null,
        isContribution:
            sourceControl.isContribution === true
    };

    /*
     * CRITICAL:
     *
     * For FieldControl, Azure layout uses:
     *
     *     id: "Custom.TaskName1"
     *
     * NOT the field GUID.
     */
    if (
        normalize(sourceControl.controlType) ===
        "fieldcontrol"
    ) {
        payload.id =
            targetFieldReferenceName;
    } else if (
        sourceControl.isContribution === true
    ) {
        payload.id =
            sourceControl.id || null;

        if (sourceControl.contribution) {
            payload.contribution =
                sourceControl.contribution;
        }
    } else {
        /*
         * Custom HTML/custom controls.
         */
        payload.id =
            sourceControl.id || null;
    }

    if (sourceControl.height !== undefined) {
        payload.height =
            sourceControl.height;
    }

    return payload;
}

/*
|--------------------------------------------------------------------------
| LAYOUT CREATE HELPERS
|--------------------------------------------------------------------------
*/

async function createPage(
    targetWitRefName,
    sourcePage,
    stats
) {
    if (MODE === "dry-run") {
        info(
            `[DRY-RUN] Would create page: ${sourcePage.label || sourcePage.id}`
        );

        stats.pages.created++;

        return {
            ...sourcePage,
            id:
                sourcePage.id ||
                `dry-run-page-${Date.now()}`,
            sections:
                getSections(sourcePage).map(
                    section => ({
                        ...section,
                        groups: []
                    })
                )
        };
    }

    try {
        const payload =
            buildPagePayload(sourcePage);

        const created =
            await post(
                `${witBase(targetWitRefName)}/layout/pages`,
                payload
            );

        info(
            `Page created: ${sourcePage.label || sourcePage.id}`
        );

        stats.pages.created++;

        return created;

    } catch (err) {
        error(
            `Page failed: ${
                sourcePage.label ||
                sourcePage.id
            } -> ${getErrorMessage(err)}`
        );

        stats.pages.failed++;

        return null;
    }
}

async function createGroup(
    targetWitRefName,
    pageId,
    sectionId,
    sourceGroup,
    stats
) {
    /*
     * IMPORTANT:
     *
     * pageId MUST be included.
     *
     * Previous broken URL:
     *
     * /layout/pages/sections/Section1/groups
     *
     * Correct URL:
     *
     * /layout/pages/{pageId}/sections/{sectionId}/groups
     */
    const url =
        `${witBase(targetWitRefName)}` +
        `/layout/pages/${enc(pageId)}` +
        `/sections/${enc(sectionId)}` +
        `/groups`;

    if (MODE === "dry-run") {
        info(
            `[DRY-RUN] Would create group: ${
                sourceGroup.label ||
                sourceGroup.id
            }`
        );

        stats.groups.created++;

        return {
            ...sourceGroup,
            id:
                sourceGroup.id ||
                `dry-run-group-${Date.now()}`,
            controls: []
        };
    }

    try {
        const payload =
            buildGroupPayload(sourceGroup);

        const created =
            await post(url, payload);

        info(
            `Group created: ${
                sourceGroup.label ||
                sourceGroup.id
            }`
        );

        stats.groups.created++;

        return created;

    } catch (err) {
        error(
            `Group failed: ${
                sourceGroup.label ||
                sourceGroup.id
            } -> ${getErrorMessage(err)}`
        );

        stats.groups.failed++;

        return null;
    }
}

async function createControl(
    targetWitRefName,
    targetGroupId,
    sourceControl,
    targetFieldReferenceName,
    stats
) {
    const url =
        `${witBase(targetWitRefName)}` +
        `/layout/groups/${enc(targetGroupId)}` +
        `/controls`;

    if (MODE === "dry-run") {
        info(
            `[DRY-RUN] Would create control: ${
                sourceControl.label ||
                sourceControl.id
            }${
                targetFieldReferenceName
                    ? ` -> ${targetFieldReferenceName}`
                    : ""
            }`
        );

        stats.controls.created++;

        return {
            ...sourceControl,
            id:
                targetFieldReferenceName ||
                sourceControl.id
        };
    }

    try {
        const payload =
            buildControlPayload(
                sourceControl,
                targetFieldReferenceName
            );

        info(
            `Creating control: ${
                sourceControl.label ||
                sourceControl.id
            }${
                targetFieldReferenceName
                    ? ` -> target field ${targetFieldReferenceName}`
                    : ""
            }`
        );

        const created =
            await post(url, payload);

        info(
            `Control created: ${
                sourceControl.label ||
                sourceControl.id
            }`
        );

        stats.controls.created++;

        return created;

    } catch (err) {
        error(
            `Control failed: ${
                sourceControl.label ||
                sourceControl.id
            } -> ${getErrorMessage(err)}`
        );

        stats.controls.failed++;

        return null;
    }
}

/*
|--------------------------------------------------------------------------
| LAYOUT MIGRATION
|--------------------------------------------------------------------------
*/

async function migrateLayout(
    sourceLayout,
    targetWitRefName,
    sourceFields,
    targetFields,
    stats
) {
    separator();
    log("LAYOUT");

    const sourceFieldMap =
        buildFieldMap(sourceFields);

    const targetFieldMap =
        buildFieldMap(targetFields);

    info(
        `Field mappings available for layout: ${targetFieldMap.size}`
    );

    /*
     * This log intentionally uses referenceName,
     * NOT field.id.
     */
    const sample = Array.from(
        targetFieldMap.values()
    )
        .slice(0, 10)
        .map(
            field =>
                `${field.referenceName} -> ${field.referenceName}`
        )
        .join(" | ");

    info(
        `Layout field map sample: ${sample}`
    );

    if (MODE === "dry-run") {
        info(
            "[DRY-RUN] Layout changes will not be written."
        );
    }

    let targetLayout;

    if (MODE === "apply") {
        targetLayout =
            await getLayout(targetWitRefName);
    } else {
        /*
         * For dry-run, use source layout as a structural
         * approximation. No writes happen anyway.
         */
        targetLayout = {
            pages: []
        };
    }

    let targetPages =
        getPages(targetLayout);

    const sourcePages =
        getPages(sourceLayout);

    for (
        let pageIndex = 0;
        pageIndex < sourcePages.length;
        pageIndex++
    ) {
        const sourcePage =
            sourcePages[pageIndex];

        /*
         * We never CREATE inherited pages.
         *
         * But we still traverse inherited pages because
         * they can contain custom groups/controls.
         */
        let targetPage =
            findPage(
                targetPages,
                sourcePage,
                pageIndex
            );

        if (targetPage) {
            info(
                `Page already exists: ${
                    sourcePage.label ||
                    sourcePage.id
                }`
            );

            stats.pages.skipped++;

        } else if (
            sourcePage.inherited === true
        ) {
            warn(
                `Inherited page not found in target, skipping creation: ${
                    sourcePage.label ||
                    sourcePage.id
                }`
            );

            stats.pages.skipped++;
            continue;

        } else {
            targetPage =
                await createPage(
                    targetWitRefName,
                    sourcePage,
                    stats
                );

            if (!targetPage) {
                continue;
            }

            /*
             * Refresh target layout after page creation.
             */
            if (MODE === "apply") {
                targetLayout =
                    await getLayout(
                        targetWitRefName
                    );

                targetPages =
                    getPages(targetLayout);

                targetPage =
                    findPage(
                        targetPages,
                        sourcePage,
                        pageIndex
                    ) || targetPage;
            }
        }

        if (!targetPage?.id) {
            error(
                `Could not resolve target page ID for ${
                    sourcePage.label ||
                    sourcePage.id
                }`
            );

            stats.pages.failed++;
            continue;
        }

        /*
         * Sections
         */
        const sourceSections =
            getSections(sourcePage);

        let targetSections =
            getSections(targetPage);

        for (
            let sectionIndex = 0;
            sectionIndex < sourceSections.length;
            sectionIndex++
        ) {
            const sourceSection =
                sourceSections[sectionIndex];

            let targetSection =
                findSection(
                    targetSections,
                    sourceSection,
                    sectionIndex
                );

            if (targetSection) {
                info(
                    `Section already exists: ${
                        sourceSection.id ||
                        `Section${sectionIndex + 1}`
                    }`
                );

                stats.sections.skipped++;

            } else {
                /*
                 * Azure's layout model normally creates
                 * Section1..Section4 as part of the page.
                 *
                 * If a source custom section is missing,
                 * we cannot safely invent a section endpoint
                 * contract. Mark it as skipped with a warning.
                 */
                warn(
                    `Section not found in target page: ${
                        sourceSection.id ||
                        `Section${sectionIndex + 1}`
                    }`
                );

                stats.sections.skipped++;
                continue;
            }

            if (!targetSection?.id) {
                error(
                    `Target section has no ID: ${
                        sourceSection.id ||
                        `Section${sectionIndex + 1}`
                    }`
                );

                stats.sections.failed++;
                continue;
            }

            /*
             * Groups
             */
            const sourceGroups =
                getGroups(sourceSection);

            let targetGroups =
                getGroups(targetSection);

            for (const sourceGroup of sourceGroups) {
                /*
                 * We do NOT skip inherited groups.
                 *
                 * Why?
                 *
                 * An inherited group such as "Description"
                 * may contain custom controls in a customized
                 * child layout.
                 *
                 * We use the inherited group as an anchor.
                 */
                let targetGroup =
                    findGroup(
                        targetGroups,
                        sourceGroup
                    );

                if (targetGroup) {
                    info(
                        `Group already exists: ${
                            sourceGroup.label ||
                            sourceGroup.id
                        }`
                    );

                    stats.groups.skipped++;

                } else if (
                    sourceGroup.inherited === true
                ) {
                    warn(
                        `Inherited group not found in target, skipping creation: ${
                            sourceGroup.label ||
                            sourceGroup.id
                        }`
                    );

                    stats.groups.skipped++;
                    continue;

                } else {
                    targetGroup =
                        await createGroup(
                            targetWitRefName,
                            targetPage.id,
                            targetSection.id,
                            sourceGroup,
                            stats
                        );

                    if (!targetGroup) {
                        continue;
                    }

                    /*
                     * Refresh layout after group creation.
                     */
                    if (MODE === "apply") {
                        targetLayout =
                            await getLayout(
                                targetWitRefName
                            );

                        targetPages =
                            getPages(targetLayout);

                        targetPage =
                            findPage(
                                targetPages,
                                sourcePage,
                                pageIndex
                            ) || targetPage;

                        targetSections =
                            getSections(
                                targetPage
                            );

                        targetSection =
                            findSection(
                                targetSections,
                                sourceSection,
                                sectionIndex
                            ) || targetSection;

                        targetGroups =
                            getGroups(
                                targetSection
                            );

                        targetGroup =
                            findGroup(
                                targetGroups,
                                sourceGroup
                            ) || targetGroup;
                    }
                }

                if (!targetGroup?.id) {
                    error(
                        `Could not resolve target group ID: ${
                            sourceGroup.label ||
                            sourceGroup.id
                        }`
                    );

                    stats.groups.failed++;
                    continue;
                }

                /*
                 * Controls
                 */
                const sourceControls =
                    getControls(sourceGroup);

                const targetControls =
                    getControls(targetGroup);

                for (const sourceControl of sourceControls) {
                    /*
                     * Never recreate inherited controls.
                     *
                     * This prevents the AttachmentsControl
                     * VS403105 problem.
                     */
                    if (
                        sourceControl.inherited === true
                    ) {
                        info(
                            `Skipping inherited control: ${
                                sourceControl.label ||
                                sourceControl.id ||
                                "Unnamed control"
                            }`
                        );

                        stats.controls.skipped++;
                        continue;
                    }

                    const sourceFieldReferenceName =
                        resolveSourceFieldReference(
                            sourceControl,
                            sourceFieldMap
                        );

                    /*
                     * If this is a field control, it MUST map
                     * to a real target field.
                     */
                    if (
                        normalize(
                            sourceControl.controlType
                        ) === "fieldcontrol"
                    ) {
                        if (!sourceFieldReferenceName) {
                            error(
                                `Control failed: ${
                                    sourceControl.label ||
                                    sourceControl.id
                                } -> Could not resolve source field reference name`
                            );

                            stats.controls.failed++;
                            continue;
                        }

                        const targetField =
                            targetFieldMap.get(
                                normalize(
                                    sourceFieldReferenceName
                                )
                            );

                        if (!targetField) {
                            error(
                                `Control failed: ${
                                    sourceControl.label ||
                                    sourceControl.id
                                } -> Target field not found: ${sourceFieldReferenceName}`
                            );

                            stats.controls.failed++;
                            continue;
                        }

                        const targetFieldReferenceName =
                            targetField.referenceName;

                        if (
                            controlAlreadyExists(
                                targetControls,
                                sourceControl,
                                sourceFieldMap,
                                targetFieldMap
                            )
                        ) {
                            info(
                                `Control already exists: ${
                                    sourceControl.label ||
                                    sourceFieldReferenceName
                                }`
                            );

                            stats.controls.skipped++;
                            continue;
                        }

                        await createControl(
                            targetWitRefName,
                            targetGroup.id,
                            sourceControl,
                            targetFieldReferenceName,
                            stats
                        );

                    } else {
                        /*
                         * Contribution / HTML / custom controls.
                         */
                        if (
                            controlAlreadyExists(
                                targetControls,
                                sourceControl,
                                sourceFieldMap,
                                targetFieldMap
                            )
                        ) {
                            info(
                                `Control already exists: ${
                                    sourceControl.label ||
                                    sourceControl.id ||
                                    "Unnamed control"
                                }`
                            );

                            stats.controls.skipped++;
                            continue;
                        }

                        await createControl(
                            targetWitRefName,
                            targetGroup.id,
                            sourceControl,
                            null,
                            stats
                        );
                    }
                }
            }
        }
    }
}

/*
|--------------------------------------------------------------------------
| STATISTICS
|--------------------------------------------------------------------------
*/

function createStats() {
    return {
        targetCreated: false,
        referenceName: null,

        fields: {
            created: 0,
            existing: 0,
            failed: 0
        },

        states: {
            created: 0,
            existing: 0,
            failed: 0
        },

        rules: {
            created: 0,
            existing: 0,
            failed: 0
        },

        pages: {
            created: 0,
            skipped: 0,
            failed: 0
        },

        sections: {
            created: 0,
            skipped: 0,
            failed: 0
        },

        groups: {
            created: 0,
            skipped: 0,
            failed: 0
        },

        controls: {
            created: 0,
            skipped: 0,
            failed: 0
        }
    };
}

function hasFailures(stats) {
    return (
        stats.fields.failed > 0 ||
        stats.states.failed > 0 ||
        stats.rules.failed > 0 ||
        stats.pages.failed > 0 ||
        stats.sections.failed > 0 ||
        stats.groups.failed > 0 ||
        stats.controls.failed > 0
    );
}

/*
|--------------------------------------------------------------------------
| SUMMARY
|--------------------------------------------------------------------------
*/

function printSummary(
    sourceName,
    targetName,
    stats
) {
    separator();

    log(
        `${sourceName} -> ${targetName}`
    );

    log(
        `Target created : ${stats.targetCreated}`
    );

    log(
        `Reference name : ${stats.referenceName}`
    );

    log(
        `Fields         : ${stats.fields.created} created / ${stats.fields.existing} existing / ${stats.fields.failed} failed`
    );

    log(
        `States         : ${stats.states.created} created / ${stats.states.existing} existing / ${stats.states.failed} failed`
    );

    log(
        `Rules          : ${stats.rules.created} created / ${stats.rules.existing} existing / ${stats.rules.failed} failed`
    );

    log(
        `Pages          : ${stats.pages.created} created / ${stats.pages.skipped} skipped / ${stats.pages.failed} failed`
    );

    log(
        `Sections       : ${stats.sections.created} created / ${stats.sections.skipped} skipped / ${stats.sections.failed} failed`
    );

    log(
        `Groups         : ${stats.groups.created} created / ${stats.groups.skipped} skipped / ${stats.groups.failed} failed`
    );

    log(
        `Controls       : ${stats.controls.created} created / ${stats.controls.skipped} skipped / ${stats.controls.failed} failed`
    );

    log(
        `Overall        : ${
            hasFailures(stats)
                ? "FAILED"
                : "SUCCESS"
        }`
    );

    separator();
}

/*
|--------------------------------------------------------------------------
| MIGRATE ONE WIT
|--------------------------------------------------------------------------
*/

async function migrateOne(mapping) {
    separator();
    log(
        `MIGRATING: ${mapping.sourceName} -> ${mapping.targetName}`
    );
    separator();

    const config =
        // loadRuntimeFile(mapping.file);
        loadRuntimeFile(mapping.outputFile);

    /*
     * Source WIT reference name comes from export.
     */
    const sourceWitRefName =
        config?.source?.referenceName ||
        config?.workItemType?.referenceName;

    if (!sourceWitRefName) {
        throw new Error(
            `Source reference name missing in ${mapping.file}`
        );
    }

    info(
        `Source reference name : ${sourceWitRefName}`
    );

    const sourceFields =
        safeArray(config.fields);

    const sourceStates =
        safeArray(config.states);

    const sourceRules =
        safeArray(config.rules);

    const sourceLayout =
        config.layout || {
            pages: []
        };

    const sourceWit =
        config;

    /*
     * Resolve/create target WIT.
     */
    const targetResult =
        await resolveTargetWit(
            mapping.targetName,
            sourceWit
        );

    const targetWit =
        targetResult.wit;

    const targetWitRefName =
        targetWit.referenceName;

    if (!targetWitRefName) {
        throw new Error(
            `Target reference name could not be resolved for ${mapping.targetName}`
        );
    }

    info(
        `Target reference name : ${targetWitRefName}`
    );

    const stats =
        createStats();

    stats.targetCreated =
        targetResult.created;

    stats.referenceName =
        targetWitRefName;

    /*
     * FIELDS
     */
    const targetFieldResult =
        await migrateFields(
            sourceFields,
            targetWitRefName,
            stats
        );

    /*
     * STATES
     */
    await migrateStates(
        sourceStates,
        targetWitRefName,
        stats
    );

    /*
     * RULES
     */
    await migrateRules(
        sourceRules,
        targetWitRefName,
        sourceWitRefName,
        stats
    );

    /*
     * LAYOUT
     */
    await migrateLayout(
        sourceLayout,
        targetWitRefName,
        sourceFields,
        targetFieldResult.fields,
        stats
    );

    printSummary(
        mapping.sourceName,
        mapping.targetName,
        stats
    );

    return {
        mapping,
        stats,
        failed: hasFailures(stats)
    };
}

/*
|--------------------------------------------------------------------------
| MAIN
|--------------------------------------------------------------------------
*/

async function main() {
    validateEnvironment();

    log("============================================================");
    log(" SAME-PROCESS WIT MIGRATION");
    log("============================================================");
    log("");
    log("Organization:");
    log(ORG);
    log("");
    log("Process:");
    log(PROCESS_ID);
    log("");
    log("Source -> Target:");
    log("  Interview Requirement -> Role Task Interview");
    log("  Interview        -> ROI BVF Scoring Interview");
    log("");
    log("Mode:");
    log(MODE);
    log("");

    separator("=");

    log("Azure DevOps Same-Process WIT Migration");
    separator("-");

    log(`Organization       : ${ORG}`);
    log(`Process ID         : ${PROCESS_ID}`);
    log(`Migration mode     : ${MODE}`);
    log(`Runtime directory  : ${RUNTIME_DIR}`);

    separator("-");

    const results = [];

    for (const mapping of WIT_MAPPINGS) {
        try {
            const result =
                await migrateOne(mapping);

            results.push(result);

        } catch (err) {
            error(
                `${mapping.sourceName} -> ${mapping.targetName} failed: ${getErrorMessage(err)}`
            );

            results.push({
                mapping,
                failed: true,
                fatalError: true
            });

            /*
             * Continue to the second WIT.
             */
        }
    }

    separator();
    log("FINAL MIGRATION SUMMARY");
    separator();

    for (const result of results) {
        log(
            `${result.mapping.sourceName} -> ${result.mapping.targetName} : ${
                result.failed
                    ? "FAILED"
                    : "SUCCESS"
            }`
        );
    }

    separator();

    const failures =
        results.filter(
            result => result.failed
        ).length;

    if (failures > 0) {
        error(
            `Migration completed with ${failures} failure(s).`
        );

        process.exitCode = 1;
        return;
    }

    log(
        "Migration completed successfully."
    );

    process.exitCode = 0;
}

/*
|--------------------------------------------------------------------------
| EXECUTE
|--------------------------------------------------------------------------
*/

main().catch(err => {
    error(
        `Fatal migration error: ${getErrorMessage(err)}`
    );

    process.exitCode = 1;
});

