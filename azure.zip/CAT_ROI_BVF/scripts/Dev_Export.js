"use strict";

const axios = require("axios");
const fs = require("fs");
const path = require("path");

/*
 * ============================================================
 * Azure DevOps - Same Process WIT Export
 * ============================================================
 *
 * SOURCE:
 *   Interview Evaluation
 *   Interview Task
 *
 * TARGET:
 *   Interview Requirement
 *   Interview Data
 *
 * IMPORTANT:
 *   Both source and target WITs belong to the SAME PROCESS.
 *
 * Required environment variables:
 *
 *   ADO_ORG
 *   ADO_PAT
 *   SOURCE_PROCESS_ID
 *
 * Optional:
 *
 *   API_VERSION
 *   RUNTIME_DIR
 *
 * Output:
 *
 *   runtime/interview-evaluation.json
 *   runtime/interview-task.json
 *   runtime/migration-map.json
 *
 * ============================================================
 */

const API_VERSION = process.env.API_VERSION || "7.1";

const ADO_ORG = process.env.ADO_ORG;
const ADO_PAT = process.env.ADO_PAT;
const SOURCE_PROCESS_ID = process.env.SOURCE_PROCESS_ID;

const RUNTIME_DIR = path.resolve(
    process.env.RUNTIME_DIR || path.join(process.cwd(), "runtime")
);

/*
 * FINAL WIT MAPPING
 */
const WIT_MAPPINGS = [
    {
        sourceName: "Interview Requirement",
        targetName: "Role Task Interview",
        outputFile: "interview-requirement.json"
    },
    {
        sourceName: "Interview",
        targetName: "ROI BVF Scoring Interview",
        outputFile: "interview.json"
    }
];

/*
 * ------------------------------------------------------------
 * Validation
 * ------------------------------------------------------------
 */

function validateEnvironment() {
    const missing = [];

    if (!ADO_ORG) {
        missing.push("ADO_ORG");
    }

    if (!ADO_PAT) {
        missing.push("ADO_PAT");
    }

    if (!SOURCE_PROCESS_ID) {
        missing.push("SOURCE_PROCESS_ID");
    }

    if (missing.length > 0) {
        throw new Error(
            `Missing required environment variables: ${missing.join(", ")}`
        );
    }
}

/*
 * ------------------------------------------------------------
 * Axios client
 * ------------------------------------------------------------
 */

function createClient() {
    const auth = Buffer
        .from(`:${ADO_PAT}`)
        .toString("base64");

    return axios.create({
        baseURL: `https://dev.azure.com/${ADO_ORG}`,
        headers: {
            Authorization: `Basic ${auth}`,
            Accept: "application/json",
            "Content-Type": "application/json"
        },
        timeout: 60000
    });
}

const client = createClient();

/*
 * ------------------------------------------------------------
 * Helpers
 * ------------------------------------------------------------
 */

function processUrl(processId, suffix = "") {
    return `/_apis/work/processes/${encodeURIComponent(processId)}${suffix}`;
}

function witUrl(processId, witRefName, suffix = "") {
    return processUrl(
        processId,
        `/workItemTypes/${encodeURIComponent(witRefName)}${suffix}`
    );
}

async function get(url) {
    try {
        const response = await client.get(url, {
            params: {
                "api-version": API_VERSION
            }
        });

        return response.data;
    } catch (error) {
        printAxiosError(`GET ${url}`, error);
        throw error;
    }
}

function printAxiosError(operation, error) {
    console.error(`\n[ERROR] ${operation}`);

    if (error.response) {
        console.error(`HTTP Status: ${error.response.status}`);

        if (error.response.data) {
            console.error(
                JSON.stringify(error.response.data, null, 2)
            );
        }
    } else {
        console.error(error.message);
    }
}

/*
 * ------------------------------------------------------------
 * Find WIT by DISPLAY NAME
 * ------------------------------------------------------------
 *
 * We intentionally resolve the referenceName from the process.
 *
 * We NEVER assume:
 *
 *   InterviewEvaluation
 *   InterviewTask
 *
 * as the API reference name.
 * ------------------------------------------------------------
 */

async function listWorkItemTypes() {
    const url = processUrl(
        SOURCE_PROCESS_ID,
        "/workItemTypes"
    );

    const data = await get(url);

    return Array.isArray(data.value)
        ? data.value
        : [];
}

async function findSourceWit(sourceName) {
    const workItemTypes = await listWorkItemTypes();

    const wit = workItemTypes.find(
        item =>
            String(item.name || "")
                .trim()
                .toLowerCase() ===
            sourceName.trim().toLowerCase()
    );

    if (!wit) {
        throw new Error(
            `Source WIT "${sourceName}" was not found in process ${SOURCE_PROCESS_ID}.`
        );
    }

    console.log(
        `  Source WIT: ${wit.name}`
    );

    console.log(
        `  Source referenceName: ${wit.referenceName}`
    );

    return wit;
}

/*
 * ------------------------------------------------------------
 * Export WIT definition
 * ------------------------------------------------------------
 */

async function exportWit(mapping) {
    console.log("\n================================================");
    console.log(`EXPORT: ${mapping.sourceName}`);
    console.log(`TARGET: ${mapping.targetName}`);
    console.log("================================================");

    const sourceWit = await findSourceWit(mapping.sourceName);

    const sourceRefName = sourceWit.referenceName;

    /*
     * Work item type metadata
     */
    const wit = await get(
        witUrl(
            SOURCE_PROCESS_ID,
            sourceRefName
        )
    );

    /*
     * Fields
     */
    console.log("  Reading fields...");

    const fields = await get(
        witUrl(
            SOURCE_PROCESS_ID,
            sourceRefName,
            "/fields"
        )
    );

    /*
     * States
     */
    console.log("  Reading states...");

    const states = await get(
        witUrl(
            SOURCE_PROCESS_ID,
            sourceRefName,
            "/states"
        )
    );

    /*
     * Rules
     */
    console.log("  Reading rules...");

    const rules = await get(
        witUrl(
            SOURCE_PROCESS_ID,
            sourceRefName,
            "/rules"
        )
    );

    /*
     * Layout
     */
    console.log("  Reading layout...");

    const layout = await get(
        witUrl(
            SOURCE_PROCESS_ID,
            sourceRefName,
            "/layout"
        )
    );

    /*
     * Build export document
     */
    const exportData = {
        schemaVersion: 2,

        exportedAt: new Date().toISOString(),

        apiVersion: API_VERSION,

        process: {
            id: SOURCE_PROCESS_ID
        },

        source: {
            name: mapping.sourceName,
            referenceName: sourceRefName
        },

        target: {
            name: mapping.targetName
        },

        workItemType: {
            referenceName: wit.referenceName,
            name: wit.name,
            description: wit.description || "",
            color: wit.color || null,
            icon: wit.icon || null,
            isDisabled: wit.isDisabled || false
        },

        fields: Array.isArray(fields.value)
            ? fields.value
            : [],

        states: Array.isArray(states.value)
            ? states.value
            : [],

        rules: Array.isArray(rules.value)
            ? rules.value
            : [],

        layout: layout || {
            pages: [],
            systemControls: [],
            extensions: []
        }
    };

    const outputPath = path.join(
        RUNTIME_DIR,
        mapping.outputFile
    );

    fs.writeFileSync(
        outputPath,
        JSON.stringify(exportData, null, 2),
        "utf8"
    );

    console.log(
        `\n  Exported: ${outputPath}`
    );

    console.log(
        `  Fields : ${exportData.fields.length}`
    );

    console.log(
        `  States : ${exportData.states.length}`
    );

    console.log(
        `  Rules  : ${exportData.rules.length}`
    );

    console.log(
        `  Pages  : ${
            Array.isArray(exportData.layout.pages)
                ? exportData.layout.pages.length
                : 0
        }`
    );

    return exportData;
}

/*
 * ------------------------------------------------------------
 * Main
 * ------------------------------------------------------------
 */

async function main() {
    console.log("\n================================================");
    console.log("Azure DevOps Same-Process WIT Export");
    console.log("================================================");

    validateEnvironment();

    fs.mkdirSync(
        RUNTIME_DIR,
        {
            recursive: true
        }
    );

    console.log(`Organization : ${ADO_ORG}`);
    console.log(`Process ID   : ${SOURCE_PROCESS_ID}`);
    console.log(`Runtime      : ${RUNTIME_DIR}`);

    const results = [];

    for (const mapping of WIT_MAPPINGS) {
        const result = await exportWit(mapping);
        results.push(result);
    }

    /*
     * Create a small migration map as well.
     */
    const migrationMap = {
        schemaVersion: 1,
        exportedAt: new Date().toISOString(),
        processId: SOURCE_PROCESS_ID,

        mappings: results.map(item => ({
            sourceName: item.source.name,
            sourceReferenceName: item.source.referenceName,
            targetName: item.target.name
        }))
    };

    const mapPath = path.join(
        RUNTIME_DIR,
        "migration-map.json"
    );

    fs.writeFileSync(
        mapPath,
        JSON.stringify(
            migrationMap,
            null,
            2
        ),
        "utf8"
    );

    console.log("\n================================================");
    console.log("EXPORT COMPLETED");
    console.log("================================================");

    console.log(
        `Migration map: ${mapPath}`
    );

    for (const item of migrationMap.mappings) {
        console.log(
            `  ${item.sourceName} -> ${item.targetName}`
        );
    }
}

main().catch(error => {
    console.error("\nEXPORT FAILED");

    console.error(
        error.message
    );

    process.exit(1);
});
